import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, AlertCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useLanguage } from '../context/LanguageContext';

export const CartDrawer: React.FC = () => {
  const {
    items,
    isCartOpen,
    setIsCartOpen,
    setIsCheckoutOpen,
    updateQuantity,
    removeItem,
    clearCart,
    couponCode,
    discountAmount,
    couponError,
    applyCoupon,
    removeCoupon,
    subtotal,
    deliveryFee,
    total,
    totalItemCount,
  } = useCart();

  const { t } = useLanguage();
  const [couponInput, setCouponInput] = useState('');

  if (!isCartOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponInput) {
      applyCoupon(couponInput);
    }
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartOpen(false)}
        className="absolute inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#120E10] border-l border-[#2C191D] text-[#F3EFEA] flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-5 border-b border-[#2C191D] flex items-center justify-between bg-[#161214]">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-[#780A12]/30 text-[#F59E0B]">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-display text-lg font-bold text-white">Your Order</h3>
                <span className="text-xs text-[#A89F95]">
                  {totalItemCount} {totalItemCount === 1 ? 'dish' : 'dishes'} selected
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {items.length > 0 && (
                <button
                  onClick={clearCart}
                  className="text-xs text-rose-400 hover:text-rose-300 px-2 py-1 transition-colors"
                >
                  Clear all
                </button>
              )}
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 rounded-lg text-[#A89F95] hover:text-white hover:bg-white/5 transition-colors"
                aria-label="Close cart"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-5 divide-y divide-[#23181B] space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-[#A89F95]">
                <div className="w-16 h-16 rounded-full bg-[#1C1518] flex items-center justify-center mb-3 text-zinc-600">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-white mb-1">Your cart is empty</h4>
                <p className="text-xs max-w-xs mb-6">
                  Add some sizzling Chicken Karahi, steaming Dum Biryani or hot Garlic Naan to get started!
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-[#780A12] hover:bg-[#8F0C15] text-white text-xs font-bold transition-all"
                >
                  Browse Menu
                </button>
              </div>
            ) : (
              items.map((cartItem) => (
                <div key={cartItem.menuItem.id} className="pt-3 first:pt-0 flex gap-3.5">
                  <img
                    src={cartItem.menuItem.image}
                    alt={cartItem.menuItem.name}
                    className="w-16 h-16 rounded-xl object-cover shrink-0 border border-[#2C191D]"
                    referrerPolicy="no-referrer"
                  />

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-sm font-semibold text-white leading-tight">
                          {cartItem.menuItem.name}
                        </h4>
                        <button
                          onClick={() => removeItem(cartItem.menuItem.id)}
                          className="text-[#8A8179] hover:text-rose-400 p-0.5 transition-colors"
                          aria-label={`Remove ${cartItem.menuItem.name}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <span className="text-[11px] font-urdu text-[#F59E0B]" dir="rtl">
                        {cartItem.menuItem.nameUrdu}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs font-bold text-[#FEF08A] tabular-nums">
                        Rs {(cartItem.menuItem.price * cartItem.quantity).toLocaleString()}
                      </span>

                      {/* Quantity stepper */}
                      <div className="flex items-center border border-[#3C2227] rounded-md bg-[#0D0B0C] p-0.5">
                        <button
                          onClick={() => updateQuantity(cartItem.menuItem.id, -1)}
                          className="w-5 h-5 flex items-center justify-center text-[#D4CDC5] hover:text-white rounded"
                        >
                          <Minus className="w-2.5 h-2.5" />
                        </button>
                        <span className="w-6 text-center text-xs font-bold text-white tabular-nums">
                          {cartItem.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(cartItem.menuItem.id, 1)}
                          className="w-5 h-5 flex items-center justify-center text-[#D4CDC5] hover:text-white rounded"
                        >
                          <Plus className="w-2.5 h-2.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer with Pricing, Coupon & Checkout */}
          {items.length > 0 && (
            <div className="p-5 border-t border-[#2C191D] bg-[#161214] space-y-4">
              {/* Coupon Form */}
              <div>
                {couponCode ? (
                  <div className="flex items-center justify-between p-2 rounded-lg bg-[#251A1D] border border-amber-500/40 text-xs">
                    <span className="text-[#FBBF24] font-semibold flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5" />
                      Promo: {couponCode} applied (-Rs {discountAmount.toLocaleString()})
                    </span>
                    <button
                      onClick={removeCoupon}
                      className="text-xs text-rose-400 hover:underline"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      placeholder="Coupon code (e.g. CHASKA10)"
                      className="flex-1 px-3 py-1.5 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white uppercase placeholder-zinc-500 focus:outline-none focus:border-[#D97706]"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-1.5 rounded-lg bg-[#3A2228] hover:bg-[#4E2E36] text-xs font-bold text-white transition-colors"
                    >
                      Apply
                    </button>
                  </form>
                )}
                {couponError && (
                  <p className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {couponError}
                  </p>
                )}
              </div>

              {/* Bill Breakdown */}
              <div className="space-y-1.5 text-xs text-[#D4CDC5] pt-2 border-t border-[#23181B]">
                <div className="flex justify-between">
                  <span>{t('subtotal')}</span>
                  <span className="tabular-nums font-semibold text-white">
                    Rs {subtotal.toLocaleString()}
                  </span>
                </div>

                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount</span>
                    <span className="tabular-nums font-semibold">
                      -Rs {discountAmount.toLocaleString()}
                    </span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>
                    Karachi Delivery Fee{' '}
                    {subtotal >= 2500 && (
                      <span className="text-[10px] text-emerald-400 font-bold">(Free over Rs 2,500)</span>
                    )}
                  </span>
                  <span className="tabular-nums font-semibold text-white">
                    {deliveryFee === 0 ? 'FREE' : `Rs ${deliveryFee}`}
                  </span>
                </div>

                <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-[#2C191D]">
                  <span>{t('total')}</span>
                  <span className="text-base text-[#FEF08A] font-serif tabular-nums">
                    Rs {total.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Checkout Trigger */}
              <button
                onClick={handleProceedToCheckout}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#25D366] to-[#128C7E] hover:from-[#22bf5b] hover:to-[#0f776a] text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(37,211,102,0.3)] transition-all cursor-pointer"
              >
                <span>Proceed to Order Details</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
