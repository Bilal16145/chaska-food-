import React, { useState } from 'react';
import { X, MessageCircle, MapPin, Phone, User, Clock, Utensils, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useOrders } from '../context/OrderContext';
import { useLanguage } from '../context/LanguageContext';
import { OrderType } from '../types/restaurant';
import { buildWhatsAppOrderMessage, generateWhatsAppUrl } from '../utils/whatsapp';
import { getKarachiRestaurantStatus } from '../utils/karachiTime';

export const CheckoutModal: React.FC = () => {
  const {
    items,
    isCheckoutOpen,
    setIsCheckoutOpen,
    subtotal,
    deliveryFee,
    discountAmount,
    total,
    clearCart,
  } = useCart();

  const { placeOrder, setIsTrackingModalOpen } = useOrders();
  const { t } = useLanguage();
  const status = getKarachiRestaurantStatus();

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [orderType, setOrderType] = useState<OrderType>('delivery');
  const [address, setAddress] = useState('');
  const [tableNumber, setTableNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [allowPreorder, setAllowPreorder] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isCheckoutOpen) return null;

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!customerName.trim() || customerName.trim().length < 2) {
      errs.name = 'Please provide your full name.';
    }
    const cleanPhone = customerPhone.replace(/\D/g, '');
    if (!cleanPhone || cleanPhone.length < 10) {
      errs.phone = 'Valid phone number required (e.g. 0327 3481948).';
    }
    if (orderType === 'delivery' && (!address.trim() || address.trim().length < 5)) {
      errs.address = 'Detailed delivery address in Karachi is required.';
    }
    if (orderType === 'dine_in' && !tableNumber.trim()) {
      errs.table = 'Please specify table number or "Walking in".';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    const orderItems = items.map((i) => ({
      itemId: i.menuItem.id,
      name: i.menuItem.name,
      price: i.menuItem.price,
      quantity: i.quantity,
    }));

    const finalNotes = [
      notes.trim(),
      !status.isOpen ? '⚡ PRE-ORDER for 5:00 PM opening' : null,
    ]
      .filter(Boolean)
      .join(' | ');

    // 1. Save order to internal database/state
    const createdOrder = placeOrder({
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      orderType,
      address: orderType === 'delivery' ? address.trim() : undefined,
      tableNumber: orderType === 'dine_in' ? tableNumber.trim() : undefined,
      items: orderItems,
      subtotal,
      deliveryFee: orderType === 'delivery' ? deliveryFee : 0,
      discount: discountAmount,
      total: orderType === 'delivery' ? total : total - deliveryFee,
      notes: finalNotes,
    });

    // 2. Build WhatsApp formatted message
    const waText = buildWhatsAppOrderMessage(createdOrder);
    const waUrl = generateWhatsAppUrl(waText);

    // 3. Open WhatsApp in new window/app
    window.open(waUrl, '_blank');

    // 4. Clear cart and switch to tracking modal
    clearCart();
    setIsCheckoutOpen(false);
    setIsSubmitting(false);
    setIsTrackingModalOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-[#140F11] border border-[#2C191D] rounded-2xl shadow-2xl text-[#F3EFEA] overflow-hidden my-8">
        {/* Header */}
        <div className="p-5 border-b border-[#2C191D] bg-[#191316] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#25D366]/20 text-[#25D366]">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-white">
                Complete WhatsApp Order
              </h3>
              <p className="text-xs text-[#A89F95]">
                Direct transmission to Chaska Foods kitchen
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsCheckoutOpen(false)}
            className="p-1.5 rounded-lg text-[#A89F95] hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Closed store advisory with pre-order option */}
        {!status.isOpen && (
          <div className="p-3.5 bg-amber-950/60 border-b border-amber-800/60 text-xs text-amber-200 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold text-white block">
                Restaurant Currently Closed (Opens at 5:00 PM Karachi Time)
              </strong>
              <span>
                You can still place a <strong className="text-amber-100">Pre-Order for 5:00 PM</strong>. Our chefs will prepare it fresh when the tandoor lights up!
              </span>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Order Type Toggle */}
          <div>
            <label className="block text-xs font-semibold text-[#D4CDC5] mb-1.5">
              Order Type:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setOrderType('delivery')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  orderType === 'delivery'
                    ? 'bg-[#780A12] text-white border border-[#D97706]'
                    : 'bg-[#21191B] text-[#A89F95] hover:text-white'
                }`}
              >
                🚚 Delivery
              </button>
              <button
                type="button"
                onClick={() => setOrderType('pickup')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  orderType === 'pickup'
                    ? 'bg-[#780A12] text-white border border-[#D97706]'
                    : 'bg-[#21191B] text-[#A89F95] hover:text-white'
                }`}
              >
                🥡 Pickup
              </button>
              <button
                type="button"
                onClick={() => setOrderType('dine_in')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  orderType === 'dine_in'
                    ? 'bg-[#780A12] text-white border border-[#D97706]'
                    : 'bg-[#21191B] text-[#A89F95] hover:text-white'
                }`}
              >
                🍽️ Dine-in
              </button>
            </div>
          </div>

          {/* Name & Phone Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-medium text-[#D4CDC5] mb-1">
                Your Full Name *
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A89F95]" />
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Asad Memon"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white placeholder-zinc-500 focus:outline-none focus:border-[#D97706]"
                />
              </div>
              {errors.name && <p className="text-[11px] text-rose-400 mt-1">{errors.name}</p>}
            </div>

            <div>
              <label className="block text-xs font-medium text-[#D4CDC5] mb-1">
                Phone Number (WhatsApp) *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A89F95]" />
                <input
                  type="tel"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="0327 3481948"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white placeholder-zinc-500 focus:outline-none focus:border-[#D97706]"
                />
              </div>
              {errors.phone && <p className="text-[11px] text-rose-400 mt-1">{errors.phone}</p>}
            </div>
          </div>

          {/* Dynamic Address / Table */}
          {orderType === 'delivery' && (
            <div>
              <label className="block text-xs font-medium text-[#D4CDC5] mb-1">
                Karachi Delivery Address & Landmark *
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-[#A89F95]" />
                <textarea
                  rows={2}
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="House/Plot #, Street, Sector 17-A / Scheme 33, Landmark near Madras Commercial..."
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white placeholder-zinc-500 focus:outline-none focus:border-[#D97706]"
                />
              </div>
              {errors.address && <p className="text-[11px] text-rose-400 mt-1">{errors.address}</p>}
            </div>
          )}

          {orderType === 'dine_in' && (
            <div>
              <label className="block text-xs font-medium text-[#D4CDC5] mb-1">
                Table Number or Seating Area *
              </label>
              <input
                type="text"
                required
                value={tableNumber}
                onChange={(e) => setTableNumber(e.target.value)}
                placeholder="Table # or 'Family AC Hall' or 'Outdoor Garden'"
                className="w-full px-3 py-2 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white placeholder-zinc-500 focus:outline-none focus:border-[#D97706]"
              />
              {errors.table && <p className="text-[11px] text-rose-400 mt-1">{errors.table}</p>}
            </div>
          )}

          {orderType === 'pickup' && (
            <div className="p-3 rounded-lg bg-[#1D171A] border border-[#3C2227] text-xs text-[#D4CDC5]">
              <span className="font-semibold text-white block mb-0.5">Pickup Location:</span>
              <span>Plot 90, 33 Madras Commercial, SBP Society, Sector 17-A Scheme, Karachi.</span>
              <span className="text-[11px] text-[#A89F95] block mt-1">Ready in ~25-35 minutes after WhatsApp confirmation.</span>
            </div>
          )}

          {/* Kitchen Notes */}
          <div>
            <label className="block text-xs font-medium text-[#D4CDC5] mb-1">
              Cooking & Special Instructions (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Kam mirchi (mild), extra salad & green raita, well-done naan..."
              className="w-full px-3 py-2 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white placeholder-zinc-500 focus:outline-none focus:border-[#D97706]"
            />
          </div>

          {/* Order Summary Snapshot */}
          <div className="p-3.5 rounded-xl bg-[#0D0B0C] border border-[#2C191D] space-y-1.5 text-xs">
            <div className="flex justify-between font-semibold text-white">
              <span>Items ({items.length} varieties)</span>
              <span>Rs {subtotal.toLocaleString()}</span>
            </div>
            {orderType === 'delivery' && (
              <div className="flex justify-between text-[#A89F95]">
                <span>Delivery (Karachi)</span>
                <span>{deliveryFee === 0 ? 'FREE' : `Rs ${deliveryFee}`}</span>
              </div>
            )}
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Discount</span>
                <span>-Rs {discountAmount.toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between text-sm font-bold text-[#FEF08A] pt-2 border-t border-[#23181B]">
              <span>Payable Total:</span>
              <span className="font-serif">
                Rs {(orderType === 'delivery' ? total : total - deliveryFee).toLocaleString()}
              </span>
            </div>
          </div>

          {/* Action Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#25D366] via-[#20BA5C] to-[#128C7E] hover:from-[#1eb956] hover:to-[#0f776a] text-black font-extrabold text-sm flex items-center justify-center gap-2.5 shadow-[0_4px_24px_rgba(37,211,102,0.4)] transition-all cursor-pointer"
          >
            <MessageCircle className="w-5 h-5 fill-black" />
            <span>
              {!status.isOpen
                ? 'Send Pre-Order on WhatsApp (+92 327 3481948)'
                : 'Send Order on WhatsApp (+92 327 3481948)'}
            </span>
          </button>

          <p className="text-[10px] text-center text-[#8C837C] flex items-center justify-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            Your order will be logged with an instant Order ID before launching WhatsApp.
          </p>
        </form>
      </div>
    </div>
  );
};
