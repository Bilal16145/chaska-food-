import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle, Phone } from 'lucide-react';
import { WHATSAPP_PHONE, DISPLAY_PHONE } from '../utils/whatsapp';

interface FAQItem {
  q: string;
  a: string;
}

const FAQS: FAQItem[] = [
  {
    q: 'Is all your food 100% Halal and fresh?',
    a: 'Absolutely. We only use 100% Zabiha Halal chicken, beef, and mutton sourced fresh every morning from reputable Karachi suppliers. No frozen pre-cooked meats are ever used.',
  },
  {
    q: 'Which areas in Karachi do you deliver to?',
    a: 'We deliver directly across Scheme 33, Sector 17-A, Madras Commercial, SBP Society, Gulshan-e-Iqbal, Malir Cantt, Gulzar-e-Hijri, Saadi Town, Super Highway societies, and nearby sectors. Free delivery on orders above Rs 2,500.',
  },
  {
    q: 'How does the WhatsApp ordering process work?',
    a: 'When you select your items on our website and tap "Order on WhatsApp", an itemized receipt is auto-generated with your name, phone, address, and an assigned Order ID (CF-XXXXX). Simply tap send on WhatsApp. Our counter acknowledges your order within 2 minutes!',
  },
  {
    q: 'Can I place pre-orders before the 5:00 PM opening time?',
    a: 'Yes! Even if you browse our menu during the daytime, you can place a pre-order for 5:00 PM. Our kitchen prepares these priority orders as soon as the deghs and tandoors fire up.',
  },
  {
    q: 'What payment methods do you accept?',
    a: 'We accept Cash on Delivery (COD) as well as direct digital payments via Raast ID, JazzCash, EasyPaisa, and online bank transfer upon order confirmation.',
  },
  {
    q: 'Is there a family dine-in hall with proper privacy?',
    a: 'Yes, our Madras Commercial branch features a comfortable family dining section as well as open-air patio seating under ambient lights.',
  },
];

export const FAQSection: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggle = (i: number) => {
    setOpenIdx(openIdx === i ? null : i);
  };

  return (
    <section id="faq" className="py-20 bg-[#0D0B0C] relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#F59E0B] flex items-center justify-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-[#F59E0B]" />
            Frequently Asked Questions
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mt-2 [text-wrap:balance]">
            Everything You Need to Know
          </h2>
          <p className="text-xs text-[#A89F95] mt-1.5">
            Quick answers regarding deliveries, family dining, and halal preparation
          </p>
        </div>

        {/* Accordion */}
        <div className="space-y-3">
          {FAQS.map((item, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="rounded-xl border border-[#2C191D] bg-[#140F11] overflow-hidden transition-colors"
              >
                <button
                  onClick={() => toggle(idx)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 hover:bg-white/[0.02] transition-colors cursor-pointer"
                >
                  <span className="text-sm font-semibold text-white">
                    {item.q}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#F59E0B] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-4 sm:px-5 pb-5 pt-1 text-xs text-[#D4CDC5] leading-relaxed border-t border-white/5 animate-in fade-in duration-150">
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Quick Contact Banner */}
        <div className="mt-12 p-6 rounded-2xl bg-[#161214] border border-[#2C191D] text-center flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="text-sm font-bold text-white">Have a special catering or party inquiry?</h4>
            <p className="text-xs text-[#A89F95] mt-0.5">
              Contact our catering team directly via WhatsApp or call our branch.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <a
              href={`https://wa.me/${WHATSAPP_PHONE}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-[#25D366] text-black font-bold text-xs flex items-center gap-1.5 shadow-md"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              WhatsApp Us
            </a>
            <a
              href="tel:03273481948"
              className="px-4 py-2 rounded-xl bg-[#241A1E] text-white font-semibold text-xs flex items-center gap-1.5 border border-[#3C2227]"
            >
              <Phone className="w-3.5 h-3.5" />
              {DISPLAY_PHONE}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
