import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showSubtitle?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', showSubtitle = true, className = '' }) => {
  const isSm = size === 'sm';
  const isMd = size === 'md';
  const isLg = size === 'lg';
  const isHero = size === 'hero';

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Authentic CF Royal Oval Crest Emblem */}
      <div
        className={`relative shrink-0 flex items-center justify-center rounded-full border border-[#EAB308]/60 bg-gradient-to-br from-[#780A12] via-[#4A070B] to-[#1F0305] shadow-[0_4px_16px_rgba(217,119,6,0.35)] transition-transform duration-300 group-hover:scale-105 ${
          isSm
            ? 'w-9 h-9'
            : isMd
            ? 'w-11 h-11'
            : isLg
            ? 'w-14 h-14'
            : 'w-20 h-20 shadow-[0_8px_32px_rgba(234,179,8,0.45)]'
        }`}
      >
        {/* Subtle decorative inner ring */}
        <div className="absolute inset-0.5 rounded-full border border-[#FDE047]/30 border-dashed animate-[spin_40s_linear_infinite]" />
        
        {/* Crest monogram CF */}
        <div className="relative flex flex-col items-center justify-center leading-none">
          <span
            className={`font-serif font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-[#FEF08A] via-[#FBBF24] to-[#B45309] drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] ${
              isSm ? 'text-sm' : isMd ? 'text-base' : isLg ? 'text-xl' : 'text-3xl'
            }`}
          >
            CF
          </span>
          {isHero && (
            <span className="text-[8px] uppercase tracking-widest text-[#FDE047] font-semibold mt-0.5">
              EST. KARACHI
            </span>
          )}
        </div>
      </div>

      {/* Brand Name with script signature styling */}
      <div className="flex flex-col">
        <div className="flex items-baseline gap-2">
          <span
            className={`font-display font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-[#FFFBEB] via-[#FDE047] to-[#F59E0B] drop-shadow-[0_2px_8px_rgba(120,10,18,0.5)] ${
              isSm
                ? 'text-lg'
                : isMd
                ? 'text-xl'
                : isLg
                ? 'text-2xl'
                : 'text-4xl md:text-5xl font-black'
            }`}
          >
            Chaska Foods
          </span>
          <span
            className={`font-urdu text-[#F59E0B]/90 font-bold ${
              isSm ? 'text-xs' : isMd ? 'text-sm' : isLg ? 'text-base' : 'text-xl'
            }`}
            dir="rtl"
          >
            چسکا فوڈز
          </span>
        </div>

        {showSubtitle && (
          <span
            className={`font-medium tracking-wide text-[#E8DFD8]/70 ${
              isSm ? 'text-[10px]' : isMd ? 'text-xs' : 'text-sm'
            }`}
          >
            Karachi Street-Food Luxury • Scheme 33
          </span>
        )}
      </div>
    </div>
  );
};
