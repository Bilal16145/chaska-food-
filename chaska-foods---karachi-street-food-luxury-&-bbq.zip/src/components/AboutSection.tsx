import React from 'react';
import { Flame, Sparkles, HeartHandshake, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const AboutSection: React.FC = () => {
  const { t, isUrdu } = useLanguage();

  return (
    <section id="story" className="py-20 bg-[#120E10] border-t border-b border-[#2C191D] relative overflow-hidden">
      {/* Subtle ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#780A12]/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-[#D97706]/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Image Showcase Left */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#3C2227] shadow-[0_20px_50px_rgba(0,0,0,0.8)] group">
              <img
                src="/src/assets/images/chaska_restaurant_ambiance_1791487534661.jpg"
                alt="Chaska Foods Family Restaurant Ambiance in Karachi"
                className="w-full h-[400px] sm:h-[480px] object-cover transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D0B0C] via-transparent to-transparent opacity-80" />

              {/* Floating card overlay */}
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-[#161214]/90 backdrop-blur-md border border-[#3C2227] flex items-center justify-between">
                <div>
                  <h4 className="font-display text-base font-bold text-white">Chaska Foods Karachi</h4>
                  <p className="text-xs text-[#E8DFD8]/80 mt-0.5">Plot 90, 33 Madras Commercial, SBP Society</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-[#F59E0B]">4.8 ★</span>
                  <p className="text-[10px] text-[#A89F95]">56 Google Reviews</p>
                </div>
              </div>
            </div>

            {/* Decorative stamp */}
            <div className="hidden sm:flex absolute -top-5 -left-5 w-24 h-24 rounded-full bg-gradient-to-br from-[#780A12] to-[#4A070B] border-2 border-[#EAB308] items-center justify-center shadow-xl rotate-12">
              <span className="text-center text-[10px] font-black uppercase text-[#FEF08A] leading-tight">
                AUTHENTIC<br />KARACHI<br />FLAVORS
              </span>
            </div>
          </div>

          {/* Editorial Content Right */}
          <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-[#F59E0B] flex items-center gap-2">
                <Flame className="w-3.5 h-3.5 text-[#F59E0B]" />
                Tradition • Passion • Freshness
              </span>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mt-2 leading-tight [text-wrap:balance]">
                Crafting Karachi’s Truest Charcoal Zaiqa Since Day One
              </h2>
              <p className="font-urdu text-lg text-[#FDE047] font-semibold mt-2" dir="rtl">
                خالص مصالحے، تازہ گوشت اور دیرپا ذائقہ جو آپ کو بار بار بلائے
              </p>
            </div>

            <p className="text-sm sm:text-base text-[#D4CDC5] leading-relaxed">
              Nestled in the bustling heart of Madras Commercial, Scheme 33, <strong className="text-white">Chaska Foods</strong> was born out of love for unhurried, authentic Pakistani culinary traditions. We believe that true Karahi and Nihari cannot be rushed with artificial seasonings or pre-made gravies.
            </p>

            <p className="text-sm sm:text-base text-[#D4CDC5] leading-relaxed">
              Every evening at 5 PM, our embers are ignited. Our master ustaads prepare traditional degs of slow-cooked <strong className="text-white">Nalli Nihari</strong>, wok-fry fresh tomatoes for <strong className="text-white">Shinwari Karahi</strong>, and fan smoking coal pits for skewers of tender <strong className="text-white">Malai Boti</strong> and <strong className="text-white">Seekh Kebabs</strong> — serving families and midnight diners right until 4:00 AM.
            </p>

            {/* 4 Pillars Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-white/10">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#780A12]/30 border border-[#780A12] text-[#F59E0B] shrink-0">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Live Wood & Coal Sigri</h4>
                  <p className="text-xs text-[#A89F95] mt-0.5">Charcoal smoke sealed into every single tender bite.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#780A12]/30 border border-[#780A12] text-[#F59E0B] shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">100% Fresh Daily Halal Meat</h4>
                  <p className="text-xs text-[#A89F95] mt-0.5">Handpicked cuts of chicken, beef, and mutton every morning.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#780A12]/30 border border-[#780A12] text-[#F59E0B] shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Pure Desi Butter & Ghee</h4>
                  <p className="text-xs text-[#A89F95] mt-0.5">Rich aroma without heavy greasy aftertastes.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#780A12]/30 border border-[#780A12] text-[#F59E0B] shrink-0">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Warm Karachi Mehmaan-Nawazi</h4>
                  <p className="text-xs text-[#A89F95] mt-0.5">Generous portions with genuine hospitality.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
