import React, { useState, useEffect } from 'react';
import { MessageCircle, Utensils, Star, Clock, MapPin, Sparkles, ArrowRight } from 'lucide-react';
import { getKarachiRestaurantStatus } from '../utils/karachiTime';
import { WHATSAPP_PHONE } from '../utils/whatsapp';
import { useLanguage } from '../context/LanguageContext';

export const Hero: React.FC = () => {
  const { t, isUrdu } = useLanguage();
  const [status, setStatus] = useState(getKarachiRestaurantStatus());

  useEffect(() => {
    const timer = setInterval(() => {
      setStatus(getKarachiRestaurantStatus());
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const heroWhatsAppText = encodeURIComponent(
    'Salam Chaska Foods! I am viewing your menu on the website and would like to place an order.'
  );

  return (
    <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden pt-20 pb-16">
      {/* Background Image with Measured Contrast Scrim */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <img
          src="/src/assets/images/hero_karahi_bbq_feast_1791487489742.jpg"
          alt="Chaska Foods Karachi BBQ, Karahi and Biryani Feast"
          className="w-full h-full object-cover object-center scale-105 filter brightness-[0.42] contrast-[1.1]"
          referrerPolicy="no-referrer"
          loading="eager"
        />
        {/* Measured dark gradient scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0B0C] via-[#0D0B0C]/70 to-[#0D0B0C]/40" />
        <div className="absolute inset-0 bg-radial from-transparent via-[#0D0B0C]/50 to-[#0D0B0C]" />
      </div>

      {/* Floating subtle steam particles simulation */}
      <div className="absolute inset-x-0 bottom-12 h-64 pointer-events-none flex justify-around opacity-25">
        <div className="w-24 h-48 bg-gradient-to-t from-white/20 to-transparent blur-2xl animate-steam" style={{ animationDelay: '0s' }} />
        <div className="w-32 h-64 bg-gradient-to-t from-amber-200/20 to-transparent blur-3xl animate-steam" style={{ animationDelay: '1.4s' }} />
        <div className="w-28 h-52 bg-gradient-to-t from-white/20 to-transparent blur-2xl animate-steam" style={{ animationDelay: '2.5s' }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center flex flex-col items-center">
        {/* Trust Badges Bar */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-6">
          {/* Live Open Status */}
          <div
            className={`inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-semibold backdrop-blur-md border ${
              status.isOpen
                ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                : 'bg-amber-950/70 border-amber-500/40 text-amber-300'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                status.isOpen ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'
              }`}
            />
            <span className="whitespace-nowrap">{status.statusBadgeText}</span>
            <span className="text-white/40">|</span>
            <span className="text-xs text-white/80 font-normal">{status.detailText}</span>
          </div>

          {/* Google Reviews rating */}
          <a
            href="https://maps.google.com/?q=Chaska+Foods+Karachi+Sector+17-A"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[#1F1417]/80 hover:bg-[#2C1B20] text-[#F3EFEA] border border-[#44232B] transition-colors"
          >
            <div className="flex text-amber-400">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
            </div>
            <span className="font-bold text-[#FBBF24]">4.8</span>
            <span className="text-[#A89F95]">(56 Google Reviews)</span>
          </a>
        </div>

        {/* Hero Headline */}
        <h1 className="font-display text-4xl sm:text-6xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-b from-[#FFFDF9] via-[#FDE047] to-[#F59E0B] tracking-tight leading-[1.1] mb-5 [text-wrap:balance]">
          Chaska Foods
        </h1>

        <p className="font-urdu text-xl sm:text-2xl md:text-3xl text-[#FEF08A] font-semibold mb-4 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" dir="rtl">
          کراچی کی اصل خوشبو اور دہکتے کوئلوں کی روایتی لذت
        </p>

        <p className="text-base sm:text-lg md:text-xl text-[#E8DFD8] max-w-2xl font-normal leading-relaxed mb-8 [text-wrap:balance]">
          From slow-simmered rich <strong className="text-white font-semibold">Nalli Nihari</strong> & sizzling <strong className="text-white font-semibold">Shinwari Karahi</strong> to melt-in-mouth <strong className="text-white font-semibold">Malai Boti</strong> and fragrant Dum Biryani. Freshly prepared in Scheme 33, Karachi.
        </p>

        {/* Action CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 w-full sm:w-auto mb-10">
          {/* Order on WhatsApp */}
          <a
            href={`https://wa.me/${WHATSAPP_PHONE}?text=${heroWhatsAppText}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl bg-gradient-to-r from-[#25D366] to-[#128C7E] hover:from-[#22bf5b] hover:to-[#0f776a] text-black font-extrabold text-sm shadow-[0_4px_24px_rgba(37,211,102,0.35)] transition-all transform hover:-translate-y-0.5 active:translate-y-0 whitespace-nowrap cursor-pointer"
          >
            <MessageCircle className="w-5 h-5 fill-black" />
            <span>{t('orderWhatsApp')}</span>
          </a>

          {/* Explore Menu */}
          <a
            href="#menu"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-[#780A12] to-[#991B1B] hover:from-[#881019] hover:to-[#A81D1D] text-white font-bold text-sm border border-[#F59E0B]/30 shadow-[0_4px_20px_rgba(120,10,18,0.4)] transition-all transform hover:-translate-y-0.5 active:translate-y-0 whitespace-nowrap"
          >
            <Utensils className="w-4 h-4 text-[#FDE047]" />
            <span>{t('viewMenu')}</span>
            <ArrowRight className="w-4 h-4 ml-1 text-[#FDE047]" />
          </a>
        </div>

        {/* 4 Trust Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 w-full max-w-4xl pt-6 border-t border-white/10">
          <div className="flex flex-col items-center p-3 rounded-lg bg-black/40 backdrop-blur-sm border border-white/5">
            <span className="text-xl sm:text-2xl font-bold font-serif text-[#FDE047] tabular-nums">4.8 ★</span>
            <span className="text-xs text-[#A89F95] mt-0.5">56 Google Reviews</span>
          </div>

          <div className="flex flex-col items-center p-3 rounded-lg bg-black/40 backdrop-blur-sm border border-white/5">
            <span className="text-xl sm:text-2xl font-bold font-serif text-white tabular-nums">5 PM – 4 AM</span>
            <span className="text-xs text-[#A89F95] mt-0.5">Daily Midnight Service</span>
          </div>

          <div className="flex flex-col items-center p-3 rounded-lg bg-black/40 backdrop-blur-sm border border-white/5">
            <span className="text-xl sm:text-2xl font-bold font-serif text-white tabular-nums">Rs 1,000–2,000</span>
            <span className="text-xs text-[#A89F95] mt-0.5">Avg Price Per Person</span>
          </div>

          <div className="flex flex-col items-center p-3 rounded-lg bg-black/40 backdrop-blur-sm border border-white/5">
            <span className="text-xl sm:text-2xl font-bold font-serif text-emerald-400">100% Halal</span>
            <span className="text-xs text-[#A89F95] mt-0.5">Dine-in, Pickup & Delivery</span>
          </div>
        </div>
      </div>
    </section>
  );
};
