import React from 'react';
import { Phone, MessageCircle, MapPin, Heart, ShieldCheck } from 'lucide-react';
import { Logo } from './Logo';
import { WHATSAPP_PHONE, DISPLAY_PHONE } from '../utils/whatsapp';

interface FooterProps {
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin }) => {
  return (
    <footer className="bg-[#090708] border-t border-[#231518] text-[#D4CDC5] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-white/5">
          {/* Brand Info */}
          <div className="lg:col-span-4 space-y-4">
            <Logo size="md" />
            <p className="text-xs text-[#A89F95] leading-relaxed pt-2 max-w-sm">
              Authentic Pakistani street-food luxury in Karachi Scheme 33. Sizzling charcoal BBQ, slow-simmered Nalli Nihari, Shinwari Karahi, and piping hot tandoori breads delivered fresh to your doorstep.
            </p>
            <div className="flex items-center gap-3 pt-1">
              <span className="text-xs font-semibold text-[#F59E0B]">4.8 ★</span>
              <span className="text-xs text-[#A89F95]">56 Google Reviews</span>
              <span className="text-[#524B46]">·</span>
              <span className="text-xs text-emerald-400 font-medium">100% Halal</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Quick Links</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#menu" className="hover:text-[#FBBF24] transition-colors">Menu Specialties</a>
              </li>
              <li>
                <a href="#story" className="hover:text-[#FBBF24] transition-colors">Charcoal Heritage</a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-[#FBBF24] transition-colors">Customer Reviews</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#FBBF24] transition-colors">Kitchen Gallery</a>
              </li>
              <li>
                <a href="#location" className="hover:text-[#FBBF24] transition-colors">Location & Hours</a>
              </li>
              <li>
                <a href="#faq" className="hover:text-[#FBBF24] transition-colors">Ordering FAQ</a>
              </li>
            </ul>
          </div>

          {/* Operating Hours */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Opening Hours</h4>
            <div className="text-xs space-y-1.5 text-[#A89F95]">
              <p className="flex justify-between">
                <span>Monday – Sunday:</span>
                <strong className="text-white">5:00 PM – 4:00 AM</strong>
              </p>
              <p className="text-[11px] text-amber-300/80">
                Open late nights for Karachi sehri & midnight dinner cravings.
              </p>
            </div>

            <div className="pt-3">
              <h5 className="text-[11px] uppercase tracking-wider font-semibold text-white mb-1">
                Average Price Range
              </h5>
              <p className="text-xs text-[#A89F95]">
                Rs 1,000 – 2,000 per person
              </p>
            </div>
          </div>

          {/* Contact & Orders */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Direct Orders</h4>
            <div className="space-y-2 text-xs text-[#A89F95]">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                <span>Plot 90, 33 Madras Commercial, SBP Society, Sector 17-A Scheme, Karachi</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#F59E0B] shrink-0" />
                <span>{DISPLAY_PHONE}</span>
              </p>
              <p className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0" />
                <a
                  href={`https://wa.me/${WHATSAPP_PHONE}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#25D366] hover:underline"
                >
                  +92 327 3481948 (WhatsApp)
                </a>
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar with AI Disclaimer and Admin Portal Link */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#716863]">
          <div>
            <p>© 2026 Chaska Foods Karachi. All rights reserved.</p>
            <p className="text-[10px] text-[#554D49] mt-0.5">
              * AI generated illustration disclaimer: Select food imagery is digitally presented for online viewing; recipes and dishes are prepared fresh daily in Karachi.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={onOpenAdmin}
              className="text-xs text-[#8C837C] hover:text-[#F59E0B] flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Staff Console</span>
            </button>
            <span>·</span>
            <span>Scheme 33, Karachi</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
