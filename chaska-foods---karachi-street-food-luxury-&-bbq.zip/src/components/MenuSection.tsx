import React, { useState, useMemo } from 'react';
import { Search, Flame, Plus, Minus, ShoppingBag, MessageCircle, Sparkles, Check, AlertCircle } from 'lucide-react';
import { MENU_ITEMS, CATEGORIES } from '../data/menuData';
import { CategoryId, MenuItem } from '../types/restaurant';
import { useCart } from '../context/CartContext';
import { useOrders } from '../context/OrderContext';
import { useLanguage } from '../context/LanguageContext';
import { buildQuickItemWhatsAppMessage, generateWhatsAppUrl } from '../utils/whatsapp';

export const MenuSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<CategoryId>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSpicyOnly, setFilterSpicyOnly] = useState(false);
  const [filterVegOnly, setFilterVegOnly] = useState(false);
  const [filterPopularOnly, setFilterPopularOnly] = useState(false);

  // Per-item quantity selection state
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [addedItemIds, setAddedItemIds] = useState<Record<string, boolean>>({});

  const { addItem, setIsCartOpen } = useCart();
  const { menuOverrides } = useOrders();
  const { isUrdu, t } = useLanguage();

  const handleQtyChange = (id: string, delta: number) => {
    const current = quantities[id] || 1;
    const next = Math.max(1, current + delta);
    setQuantities((prev) => ({ ...prev, [id]: next }));
  };

  const handleAddToCart = (item: MenuItem) => {
    const qty = quantities[item.id] || 1;
    addItem(item, qty);
    setAddedItemIds((prev) => ({ ...prev, [item.id]: true }));
    setTimeout(() => {
      setAddedItemIds((prev) => ({ ...prev, [item.id]: false }));
    }, 1500);
  };

  const handleQuickWhatsApp = (item: MenuItem) => {
    const qty = quantities[item.id] || 1;
    const effectivePrice = menuOverrides[item.id]?.price ?? item.price;
    const msg = buildQuickItemWhatsAppMessage(item.name, effectivePrice, qty);
    window.open(generateWhatsAppUrl(msg), '_blank');
  };

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.map((item) => {
      // Merge with admin overrides if present
      const override = menuOverrides[item.id];
      return {
        ...item,
        price: override?.price !== undefined ? override.price : item.price,
        isAvailable: override?.isAvailable !== undefined ? override.isAvailable : item.isAvailable,
      };
    }).filter((item) => {
      // Category filter
      if (activeCategory !== 'all' && item.category !== activeCategory) {
        return false;
      }
      // Search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesUrdu = item.nameUrdu.includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        if (!matchesName && !matchesUrdu && !matchesDesc) return false;
      }
      // Dietary/Flavor filters
      if (filterSpicyOnly && item.spiceLevel !== 'hot' && item.spiceLevel !== 'extra-hot') {
        return false;
      }
      if (filterVegOnly && !item.isVegetarian) {
        return false;
      }
      if (filterPopularOnly && !item.isPopular && !item.isChefSpecial) {
        return false;
      }
      return true;
    });
  }, [activeCategory, searchQuery, filterSpicyOnly, filterVegOnly, filterPopularOnly, menuOverrides]);

  return (
    <section id="menu" className="py-20 bg-[#0D0B0C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#F59E0B] flex items-center justify-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-[#F59E0B]" />
            Pakistani Cuisine • Karachi Recipes
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-black text-white mt-2 mb-3 [text-wrap:balance]">
            Our Authentic Karachi Menu
          </h2>
          <p className="font-urdu text-xl text-[#FDE047] font-semibold mb-3" dir="rtl">
            تازہ تیار کردہ لذیذ کڑاہی، خوشبودار بریانی اور دہکتا باربی کیو
          </p>
          <p className="text-sm text-[#A89F95] [text-wrap:balance]">
            Handcrafted with freshly grounded whole spices and 100% Halal prime cuts. Available for Dine-in, Pickup, and Fast Delivery across Karachi Scheme 33 & surrounding areas.
          </p>
        </div>

        {/* Search & Dietary Controls */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8 bg-[#161214] p-3 sm:p-4 rounded-xl border border-[#2C191D]">
          {/* Search Bar */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A89F95]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Karahi, Biryani, Naan, Tikka..."
              className="w-full pl-10 pr-4 py-2 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white placeholder-[#786F69] focus:outline-none focus:border-[#D97706] transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#A89F95] hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick Filter Buttons */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <button
              onClick={() => setFilterPopularOnly(!filterPopularOnly)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                filterPopularOnly
                  ? 'bg-[#780A12] text-white border border-[#D97706]'
                  : 'bg-[#21191B] text-[#D4CDC5] hover:bg-[#2D2124]'
              }`}
            >
              ★ Chef's Special
            </button>
            <button
              onClick={() => setFilterSpicyOnly(!filterSpicyOnly)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                filterSpicyOnly
                  ? 'bg-[#991B1B] text-white border border-[#EF4444]'
                  : 'bg-[#21191B] text-[#D4CDC5] hover:bg-[#2D2124]'
              }`}
            >
              🌶️ Spicy (Teekha)
            </button>
            <button
              onClick={() => setFilterVegOnly(!filterVegOnly)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                filterVegOnly
                  ? 'bg-emerald-900 text-white border border-emerald-500'
                  : 'bg-[#21191B] text-[#D4CDC5] hover:bg-[#2D2124]'
              }`}
            >
              🌿 Vegetarian
            </button>
          </div>
        </div>

        {/* Category Tabs (Segmented controls) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as CategoryId)}
                className={`px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-[#780A12] to-[#991B1B] text-[#FFFBEB] shadow-[0_2px_12px_rgba(120,10,18,0.4)] border border-[#EAB308]/40 scale-102'
                    : 'bg-[#161214] text-[#D4CDC5] hover:bg-[#221A1D] hover:text-white border border-[#2C191D]'
                }`}
              >
                <span>{cat.name}</span>
                <span className="ml-1.5 text-[10px] opacity-75 font-normal">
                  ({cat.nameUrdu})
                </span>
              </button>
            );
          })}
        </div>

        {/* Menu Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-[#140F11] rounded-2xl border border-[#2C191D] p-8">
            <AlertCircle className="w-10 h-10 text-[#F59E0B] mx-auto mb-3" />
            <h3 className="text-lg font-bold text-white mb-1">No Dishes Found</h3>
            <p className="text-xs text-[#A89F95] mb-4">
              We couldn't find any dishes matching "{searchQuery}". Try searching for Karahi, Biryani, or Naan.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setActiveCategory('all');
                setFilterSpicyOnly(false);
                setFilterVegOnly(false);
                setFilterPopularOnly(false);
              }}
              className="px-4 py-2 rounded-lg bg-[#780A12] text-white text-xs font-semibold"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
            {filteredItems.map((dish) => {
              const qty = quantities[dish.id] || 1;
              const isAdded = addedItemIds[dish.id];

              return (
                <div
                  key={dish.id}
                  className={`group rounded-2xl bg-[#140F11] border border-[#2C191D] hover:border-[#780A12]/80 transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-[0_8px_24px_rgba(0,0,0,0.4)] hover:shadow-[0_12px_32px_rgba(120,10,18,0.25)] hover:-translate-y-1 ${
                    !dish.isAvailable ? 'opacity-70 grayscale-[25%]' : ''
                  }`}
                >
                  {/* Dish Image Container */}
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#1E1618]">
                    <img
                      src={dish.image}
                      alt={dish.name}
                      className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-108"
                      referrerPolicy="no-referrer"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#140F11] via-transparent to-transparent opacity-90" />

                    {/* Unboxed Metadata (Disciplined single text badge) */}
                    {dish.isChefSpecial ? (
                      <span className="absolute top-3 left-3 text-[11px] font-bold text-[#FEF08A] bg-[#780A12]/90 backdrop-blur-md px-2.5 py-0.5 rounded-md border border-[#F59E0B]/50">
                        Chef's Special
                      </span>
                    ) : dish.isPopular ? (
                      <span className="absolute top-3 left-3 text-[11px] font-bold text-white bg-black/70 backdrop-blur-md px-2.5 py-0.5 rounded-md border border-white/20">
                        Popular
                      </span>
                    ) : null}

                    {/* Out of Stock Banner */}
                    {!dish.isAvailable && (
                      <div className="absolute inset-0 bg-black/75 backdrop-blur-[2px] flex items-center justify-center p-4">
                        <span className="px-3 py-1.5 rounded-lg bg-red-950 text-red-200 border border-red-700 text-xs font-bold uppercase tracking-wider">
                          Sold Out Tonight
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Dish Details */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Quiet Unboxed Metadata Line */}
                      <div className="flex items-center gap-2 text-[11px] text-[#A89F95] mb-1.5">
                        <span className="uppercase tracking-wider font-semibold text-[#D97706]">
                          {dish.category.toUpperCase().replace('_', ' ')}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>Serves: {dish.serves}</span>
                        <span aria-hidden="true">·</span>
                        <span className="capitalize">{dish.spiceLevel} spice</span>
                      </div>

                      {/* Dish Titles */}
                      <div className="flex items-baseline justify-between gap-2 mb-1">
                        <h3 className="font-display text-lg font-bold text-white group-hover:text-[#FDE047] transition-colors leading-snug">
                          {dish.name}
                        </h3>
                      </div>

                      <p className="font-urdu text-sm text-[#FBBF24]/90 font-medium mb-2" dir="rtl">
                        {dish.nameUrdu}
                      </p>

                      <p className="text-xs text-[#B5ABA1] line-clamp-2 leading-relaxed mb-4">
                        {dish.description}
                      </p>
                    </div>

                    {/* Price and Cart Action Footer */}
                    <div className="pt-4 border-t border-[#251A1D]">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <span className="text-[10px] uppercase text-[#A89F95] block">Price</span>
                          <span className="text-lg font-bold font-serif text-[#FEF08A] tabular-nums">
                            Rs {dish.price.toLocaleString()}
                          </span>
                        </div>

                        {/* Quantity Stepper */}
                        {dish.isAvailable && (
                          <div className="flex items-center border border-[#3C2227] rounded-lg bg-[#0D0B0C] p-0.5">
                            <button
                              onClick={() => handleQtyChange(dish.id, -1)}
                              className="w-7 h-7 flex items-center justify-center text-[#D4CDC5] hover:text-white hover:bg-white/5 rounded transition-colors"
                              aria-label={`Decrease ${dish.name} quantity`}
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-6 text-center text-xs font-bold text-white tabular-nums">
                              {qty}
                            </span>
                            <button
                              onClick={() => handleQtyChange(dish.id, 1)}
                              className="w-7 h-7 flex items-center justify-center text-[#D4CDC5] hover:text-white hover:bg-white/5 rounded transition-colors"
                              aria-label={`Increase ${dish.name} quantity`}
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Action Buttons: Add to Cart + Quick WhatsApp */}
                      <div className="grid grid-cols-2 gap-2">
                        {/* Add to Cart */}
                        <button
                          disabled={!dish.isAvailable}
                          onClick={() => handleAddToCart(dish)}
                          className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            isAdded
                              ? 'bg-emerald-600 text-white'
                              : dish.isAvailable
                              ? 'bg-[#780A12] hover:bg-[#8F0C15] text-white shadow-sm'
                              : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                          }`}
                        >
                          {isAdded ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>{t('added')}</span>
                            </>
                          ) : (
                            <>
                              <ShoppingBag className="w-3.5 h-3.5" />
                              <span>{t('addToCart')}</span>
                            </>
                          )}
                        </button>

                        {/* Direct WhatsApp Order */}
                        <button
                          disabled={!dish.isAvailable}
                          onClick={() => handleQuickWhatsApp(dish)}
                          className="py-2 px-2.5 rounded-lg text-xs font-semibold bg-[#1D3222] hover:bg-[#25452C] text-[#25D366] border border-[#25D366]/30 flex items-center justify-center gap-1 transition-colors cursor-pointer"
                          title="Instant order via WhatsApp"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span className="truncate">WhatsApp</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
