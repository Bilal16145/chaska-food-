import React from 'react';
import { MapPin, Phone, MessageCircle, Clock, Navigation, CheckCircle, ExternalLink } from 'lucide-react';
import { getKarachiRestaurantStatus } from '../utils/karachiTime';
import { WHATSAPP_PHONE, DISPLAY_PHONE } from '../utils/whatsapp';

export const LocationHoursSection: React.FC = () => {
  const status = getKarachiRestaurantStatus();

  const googleMapsUrl = 'https://maps.google.com/?q=Plot+90+33+Madras+Commercial+SBP+Society+Sector+17-A+Scheme+Karachi';

  const schedule = [
    { day: 'Monday', hours: '5:00 PM – 4:00 AM' },
    { day: 'Tuesday', hours: '5:00 PM – 4:00 AM' },
    { day: 'Wednesday', hours: '5:00 PM – 4:00 AM' },
    { day: 'Thursday', hours: '5:00 PM – 4:00 AM' },
    { day: 'Friday', hours: '5:00 PM – 4:00 AM (Special Juma Deghs)' },
    { day: 'Saturday', hours: '5:00 PM – 4:00 AM (Late Night Weekend)' },
    { day: 'Sunday', hours: '5:00 PM – 4:00 AM (Family Dining Special)' },
  ];

  return (
    <section id="location" className="py-20 bg-[#120E10] border-t border-b border-[#2C191D] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#F59E0B] flex items-center justify-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#F59E0B]" />
            Karachi Branch • Scheme 33
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mt-2 [text-wrap:balance]">
            Find Us in Karachi
          </h2>
          <p className="text-xs text-[#A89F95] mt-1.5">
            Plot 90, 33 Madras Commercial, SBP Society, Sector 17-A Scheme, Karachi
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Map Embed Container */}
          <div className="lg:col-span-7 bg-[#161214] border border-[#2C191D] rounded-3xl overflow-hidden shadow-xl flex flex-col">
            <div className="relative aspect-[16/10] w-full bg-[#1F191B]">
              {/* Responsive Google Maps Embed */}
              <iframe
                title="Chaska Foods Karachi Map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14467.502805470716!2d67.1264!3d24.9602!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33890f1234567%3A0x89abcdef12345678!2sSector%2017-A%20Scheme%2033%2C%20Karachi!5e0!3m2!1sen!2spk!4v1700000000000!5m2!1sen!2spk"
                className="w-full h-full border-0 filter contrast-[1.05] brightness-[0.9]"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />

              {/* Live badge overlay on map */}
              <div className="absolute top-4 left-4 p-2.5 rounded-xl bg-[#0D0B0C]/90 backdrop-blur-md border border-[#3C2227] flex items-center gap-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    status.isOpen ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                  }`}
                />
                <span className="text-xs font-bold text-white">
                  {status.statusBadgeText}
                </span>
              </div>
            </div>

            {/* Quick Actions Under Map */}
            <div className="p-5 flex flex-wrap items-center justify-between gap-3 bg-[#181215] border-t border-[#2C191D]">
              <div>
                <h4 className="text-sm font-bold text-white">Chaska Foods Branch</h4>
                <p className="text-xs text-[#A89F95] mt-0.5">
                  Easy parking • Family hall • Open air seating
                </p>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-lg bg-[#780A12] hover:bg-[#8F0C15] text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Get Directions</span>
                </a>
                <a
                  href="tel:03273481948"
                  className="px-3.5 py-2 rounded-lg bg-[#241A1E] hover:bg-[#33242A] text-[#F3EFEA] text-xs font-semibold flex items-center gap-1.5 transition-colors border border-[#3C2227]"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Us</span>
                </a>
              </div>
            </div>
          </div>

          {/* Business Details & Hours Schedule */}
          <div className="lg:col-span-5 space-y-6">
            {/* Contact Card */}
            <div className="p-6 rounded-2xl bg-[#161214] border border-[#2C191D] space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#F59E0B]" />
                Operating Hours (Karachi PKT)
              </h3>

              <div className="space-y-2 text-xs">
                {schedule.map((item, i) => (
                  <div
                    key={item.day}
                    className="flex justify-between py-1.5 border-b border-[#23181B] last:border-0"
                  >
                    <span className="text-[#A89F95]">{item.day}</span>
                    <span className="font-semibold text-white">{item.hours}</span>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-[#23181B] space-y-2 text-xs">
                <div className="flex items-start gap-2.5 text-[#D4CDC5]">
                  <MapPin className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                  <span>
                    Plot 90, 33 Madras Commercial, SBP Society, Sector 17-A Scheme, Karachi
                  </span>
                </div>

                <div className="flex items-center gap-2.5 text-[#D4CDC5]">
                  <Phone className="w-4 h-4 text-[#F59E0B] shrink-0" />
                  <span>{DISPLAY_PHONE}</span>
                </div>

                <div className="flex items-center gap-2.5 text-[#D4CDC5]">
                  <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0" />
                  <a
                    href={`https://wa.me/${WHATSAPP_PHONE}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#25D366] hover:underline font-semibold"
                  >
                    WhatsApp: +92 327 3481948
                  </a>
                </div>
              </div>
            </div>

            {/* Service Capabilities Card */}
            <div className="p-5 rounded-2xl bg-[#161214] border border-[#2C191D]">
              <span className="text-xs uppercase text-[#A89F95] font-semibold block mb-2">
                Available Dining Modes
              </span>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2.5 rounded-xl bg-[#21191B] border border-[#2C191D]">
                  <span className="block font-bold text-white">Dine-in</span>
                  <span className="text-[10px] text-[#A89F95]">Family Seating</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#21191B] border border-[#2C191D]">
                  <span className="block font-bold text-white">Pickup</span>
                  <span className="text-[10px] text-[#A89F95]">Takeaway Counter</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#21191B] border border-[#2C191D]">
                  <span className="block font-bold text-white">Delivery</span>
                  <span className="text-[10px] text-[#A89F95]">Fast Riders</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
