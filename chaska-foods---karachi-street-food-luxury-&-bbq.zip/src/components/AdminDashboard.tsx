import React, { useState, useMemo } from 'react';
import {
  X,
  Lock,
  DollarSign,
  ShoppingBag,
  Clock,
  TrendingUp,
  Download,
  Volume2,
  Check,
  AlertCircle,
  Eye,
  Trash2,
  Plus,
  RefreshCw,
  Search,
  CheckCircle2,
  Phone,
  MessageCircle,
} from 'lucide-react';
import { useOrders } from '../context/OrderContext';
import { MENU_ITEMS } from '../data/menuData';
import { Order, OrderStatus } from '../types/restaurant';
import { WHATSAPP_PHONE } from '../utils/whatsapp';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ isOpen, onClose }) => {
  const {
    orders,
    updateOrderStatus,
    deleteOrder,
    menuOverrides,
    updateMenuPrice,
    toggleItemAvailability,
    playOrderAlertSound,
  } = useOrders();

  // Security gate
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return sessionStorage.getItem('chaska_admin_auth') === 'true';
  });
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [failedAttempts, setFailedAttempts] = useState(0);

  // Tabs: 'orders' | 'menu' | 'analytics'
  const [activeTab, setActiveTab] = useState<'orders' | 'menu' | 'analytics'>('orders');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [menuSearch, setMenuSearch] = useState('');
  const [editingPriceId, setEditingPriceId] = useState<string | null>(null);
  const [tempPriceInput, setTempPriceInput] = useState<string>('');

  if (!isOpen) return null;

  // Handle Login PIN
  // Demo PIN: 1948 (matching Chaska phone number suffix 1948)
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (failedAttempts >= 5) {
      setPinError('Account locked due to 5 failed attempts. Please refresh later.');
      return;
    }
    if (pinInput === '1948' || pinInput === 'admin') {
      setIsAuthenticated(true);
      sessionStorage.setItem('chaska_admin_auth', 'true');
      setPinError('');
    } else {
      setFailedAttempts((prev) => prev + 1);
      setPinError(`Incorrect PIN. (${5 - (failedAttempts + 1)} attempts remaining. Default PIN: 1948)`);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('chaska_admin_auth');
    setPinInput('');
  };

  // Metrics calculation
  const totalRevenue = orders
    .filter((o) => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.total, 0);

  const activeOrdersCount = orders.filter(
    (o) => o.status === 'new' || o.status === 'preparing' || o.status === 'ready' || o.status === 'out_for_delivery'
  ).length;

  const deliveredCount = orders.filter((o) => o.status === 'delivered').length;

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    if (statusFilter === 'all') return true;
    return o.status === statusFilter;
  });

  // Export to CSV
  const exportToCSV = () => {
    const headers = ['Order ID', 'Customer', 'Phone', 'Type', 'Address', 'Status', 'Total (PKR)', 'Date'];
    const rows = orders.map((o) => [
      o.id,
      `"${o.customerName}"`,
      `"${o.customerPhone}"`,
      o.orderType,
      `"${o.address || o.tableNumber || 'N/A'}"`,
      o.status,
      o.total,
      new Date(o.createdAt).toLocaleString(),
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Chaska_Orders_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered Menu Items
  const filteredMenuItems = MENU_ITEMS.filter((m) => {
    if (!menuSearch) return true;
    const q = menuSearch.toLowerCase();
    return m.name.toLowerCase().includes(q) || m.nameUrdu.includes(q);
  });

  const savePrice = (itemId: string) => {
    const val = parseInt(tempPriceInput, 10);
    if (!isNaN(val) && val > 0) {
      updateMenuPrice(itemId, val);
    }
    setEditingPriceId(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div className="relative w-full max-w-5xl bg-[#140F11] border border-[#3C2227] rounded-2xl shadow-2xl text-[#F3EFEA] overflow-hidden my-4 max-h-[92vh] flex flex-col">
        {/* Header Bar */}
        <div className="p-4 sm:p-5 border-b border-[#2C191D] bg-[#191316] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#780A12] border border-[#EAB308]/50 flex items-center justify-center text-[#FEF08A] font-bold text-xs">
              CF
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-white">
                Chaska Foods Staff Console
              </h3>
              <p className="text-xs text-[#A89F95]">
                Kitchen Management, Menu Pricing & Order Dispatch
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <>
                <button
                  onClick={playOrderAlertSound}
                  className="p-2 rounded-lg bg-[#241A1E] hover:bg-[#33242A] text-amber-400 border border-[#3C2227] transition-colors"
                  title="Test kitchen chime bell"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#241A1E] hover:bg-rose-950 text-rose-300 border border-[#3C2227] transition-colors"
                >
                  Lock
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#A89F95] hover:text-white hover:bg-white/5 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        {!isAuthenticated ? (
          /* Secure PIN Gate */
          <div className="p-8 sm:p-12 flex flex-col items-center justify-center max-w-sm mx-auto text-center">
            <div className="w-14 h-14 rounded-full bg-[#780A12]/30 border border-[#780A12] flex items-center justify-center text-[#F59E0B] mb-4">
              <Lock className="w-6 h-6" />
            </div>
            <h4 className="font-display text-xl font-bold text-white mb-1">
              Restricted Staff Access
            </h4>
            <p className="text-xs text-[#A89F95] mb-6">
              Enter the manager PIN to access kitchen orders, toggle stock, and modify prices.
            </p>

            <form onSubmit={handleLogin} className="w-full space-y-4">
              <div>
                <input
                  type="password"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="Enter PIN (e.g. 1948)"
                  className="w-full text-center tracking-widest text-lg font-bold py-3 px-4 rounded-xl bg-[#0D0B0C] border border-[#3C2227] text-white focus:outline-none focus:border-[#D97706]"
                  autoFocus
                />
                {pinError && (
                  <p className="text-xs text-rose-400 mt-2 flex items-center justify-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {pinError}
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#780A12] to-[#991B1B] hover:from-[#8B0C15] hover:to-[#B91C1C] text-white font-bold text-xs uppercase tracking-wider transition-all"
              >
                Authenticate Console
              </button>

              <p className="text-[11px] text-[#786F69]">
                Hint: Default branch PIN is <span className="text-amber-400 font-mono">1948</span>
              </p>
            </form>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Top Navigation Tabs */}
            <div className="px-5 pt-3 border-b border-[#2C191D] bg-[#161214] flex flex-wrap items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`py-2 px-4 text-xs font-bold rounded-t-lg transition-colors border-b-2 ${
                    activeTab === 'orders'
                      ? 'border-[#D97706] text-white bg-[#140F11]'
                      : 'border-transparent text-[#A89F95] hover:text-white'
                  }`}
                >
                  Live Orders ({orders.length})
                </button>
                <button
                  onClick={() => setActiveTab('menu')}
                  className={`py-2 px-4 text-xs font-bold rounded-t-lg transition-colors border-b-2 ${
                    activeTab === 'menu'
                      ? 'border-[#D97706] text-white bg-[#140F11]'
                      : 'border-transparent text-[#A89F95] hover:text-white'
                  }`}
                >
                  Menu Pricing & Stock
                </button>
                <button
                  onClick={() => setActiveTab('analytics')}
                  className={`py-2 px-4 text-xs font-bold rounded-t-lg transition-colors border-b-2 ${
                    activeTab === 'analytics'
                      ? 'border-[#D97706] text-white bg-[#140F11]'
                      : 'border-transparent text-[#A89F95] hover:text-white'
                  }`}
                >
                  Daily Summary
                </button>
              </div>

              {activeTab === 'orders' && (
                <div className="flex items-center gap-2 pb-2">
                  <button
                    onClick={exportToCSV}
                    className="px-3 py-1.5 rounded-lg bg-[#241A1E] hover:bg-[#33242A] text-xs font-semibold text-white border border-[#3C2227] flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Export CSV
                  </button>
                </div>
              )}
            </div>

            {/* Scrollable Tab Panel */}
            <div className="flex-1 overflow-y-auto p-5">
              {/* TAB 1: ORDERS */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  {/* Status Filters */}
                  <div className="flex items-center gap-2 overflow-x-auto pb-2">
                    {['all', 'new', 'preparing', 'ready', 'out_for_delivery', 'delivered'].map(
                      (st) => (
                        <button
                          key={st}
                          onClick={() => setStatusFilter(st)}
                          className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize whitespace-nowrap transition-colors ${
                            statusFilter === st
                              ? 'bg-[#780A12] text-white'
                              : 'bg-[#21191B] text-[#A89F95] hover:text-white'
                          }`}
                        >
                          {st.replace('_', ' ')}
                        </button>
                      )
                    )}
                  </div>

                  {/* Orders Cards List */}
                  {filteredOrders.length === 0 ? (
                    <div className="text-center py-12 text-[#A89F95] text-xs">
                      No orders found under "{statusFilter}".
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {filteredOrders.map((ord) => (
                        <div
                          key={ord.id}
                          className="p-4 rounded-xl bg-[#181215] border border-[#2C191D] hover:border-[#3C2227] transition-colors flex flex-col md:flex-row justify-between gap-4"
                        >
                          <div className="space-y-1.5 flex-1">
                            <div className="flex items-center gap-2.5">
                              <span className="font-serif font-bold text-base text-[#FEF08A]">
                                {ord.id}
                              </span>
                              <span className="text-xs px-2 py-0.5 rounded-md bg-[#251A1D] text-[#D4CDC5] font-semibold uppercase">
                                {ord.orderType}
                              </span>
                              <span className="text-[11px] text-[#A89F95]">
                                {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>

                            <div className="text-xs text-[#D4CDC5]">
                              <strong className="text-white">{ord.customerName}</strong> ({ord.customerPhone})
                            </div>

                            <p className="text-xs text-[#A89F95]">
                              {ord.address || ord.tableNumber || 'Pickup'}
                            </p>

                            {ord.notes && (
                              <p className="text-xs text-amber-300/90 italic">
                                Note: {ord.notes}
                              </p>
                            )}

                            {/* Itemized line */}
                            <div className="pt-2 text-xs text-[#B5ABA1]">
                              {ord.items.map((it) => `${it.quantity}x ${it.name}`).join(' • ')}
                            </div>
                          </div>

                          {/* Right Status Controls */}
                          <div className="flex flex-col md:items-end justify-between gap-3 shrink-0">
                            <span className="font-serif font-bold text-base text-[#FEF08A] tabular-nums">
                              Rs {ord.total.toLocaleString()}
                            </span>

                            {/* Status Switcher Select */}
                            <div className="flex items-center gap-2">
                              <select
                                value={ord.status}
                                onChange={(e) => updateOrderStatus(ord.id, e.target.value as OrderStatus)}
                                className="px-3 py-1.5 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white focus:outline-none focus:border-[#D97706]"
                              >
                                <option value="new">New</option>
                                <option value="preparing">Preparing</option>
                                <option value="ready">Ready</option>
                                <option value="out_for_delivery">Out for Delivery</option>
                                <option value="delivered">Delivered</option>
                                <option value="cancelled">Cancelled</option>
                              </select>

                              <button
                                onClick={() => deleteOrder(ord.id)}
                                className="p-1.5 rounded-lg text-[#786F69] hover:text-rose-400 hover:bg-white/5 transition-colors"
                                title="Delete Order"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: MENU PRICING & STOCK */}
              {activeTab === 'menu' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-4">
                    <div className="relative flex-1 max-w-sm">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A89F95]" />
                      <input
                        type="text"
                        value={menuSearch}
                        onChange={(e) => setMenuSearch(e.target.value)}
                        placeholder="Search dish to edit..."
                        className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-[#0D0B0C] border border-[#3C2227] text-white focus:outline-none focus:border-[#D97706]"
                      />
                    </div>
                    <span className="text-xs text-[#A89F95]">
                      Click price to update in PKR
                    </span>
                  </div>

                  <div className="divide-y divide-[#2C191D] border border-[#2C191D] rounded-xl overflow-hidden bg-[#161214]">
                    {filteredMenuItems.map((item) => {
                      const override = menuOverrides[item.id];
                      const currentPrice = override?.price !== undefined ? override.price : item.price;
                      const isAvailable = override?.isAvailable !== undefined ? override.isAvailable : item.isAvailable;
                      const isEditing = editingPriceId === item.id;

                      return (
                        <div
                          key={item.id}
                          className="p-3.5 flex items-center justify-between gap-4 hover:bg-white/[0.01] transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-12 h-12 rounded-lg object-cover border border-[#2C191D]"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <h4 className="text-xs font-bold text-white">{item.name}</h4>
                              <span className="text-[11px] font-urdu text-[#F59E0B]" dir="rtl">
                                {item.nameUrdu}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-4">
                            {/* Price editor */}
                            {isEditing ? (
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="number"
                                  value={tempPriceInput}
                                  onChange={(e) => setTempPriceInput(e.target.value)}
                                  className="w-20 px-2 py-1 text-xs rounded bg-[#0D0B0C] border border-[#D97706] text-white"
                                  autoFocus
                                />
                                <button
                                  onClick={() => savePrice(item.id)}
                                  className="px-2 py-1 bg-emerald-700 text-white text-xs rounded font-bold"
                                >
                                  Save
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => {
                                  setEditingPriceId(item.id);
                                  setTempPriceInput(String(currentPrice));
                                }}
                                className="text-xs font-bold text-[#FEF08A] hover:underline cursor-pointer"
                                title="Click to edit price"
                              >
                                Rs {currentPrice.toLocaleString()}
                              </button>
                            )}

                            {/* Stock toggle */}
                            <button
                              onClick={() => toggleItemAvailability(item.id)}
                              className={`px-3 py-1 rounded-md text-xs font-bold transition-colors ${
                                isAvailable
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                                  : 'bg-rose-950 text-rose-300 border border-rose-700'
                              }`}
                            >
                              {isAvailable ? 'In Stock' : 'Sold Out'}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 3: DAILY SUMMARY */}
              {activeTab === 'analytics' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-5 rounded-xl bg-[#181215] border border-[#2C191D]">
                      <span className="text-xs uppercase text-[#A89F95] font-semibold block">
                        Gross Sales
                      </span>
                      <span className="text-2xl font-bold font-serif text-[#FEF08A] mt-1 block tabular-nums">
                        Rs {totalRevenue.toLocaleString()}
                      </span>
                      <span className="text-[11px] text-[#A89F95] mt-1 block">
                        Across {orders.length} total orders
                      </span>
                    </div>

                    <div className="p-5 rounded-xl bg-[#181215] border border-[#2C191D]">
                      <span className="text-xs uppercase text-[#A89F95] font-semibold block">
                        Active In Kitchen
                      </span>
                      <span className="text-2xl font-bold font-serif text-amber-400 mt-1 block tabular-nums">
                        {activeOrdersCount} orders
                      </span>
                      <span className="text-[11px] text-[#A89F95] mt-1 block">
                        Preparing & out for delivery
                      </span>
                    </div>

                    <div className="p-5 rounded-xl bg-[#181215] border border-[#2C191D]">
                      <span className="text-xs uppercase text-[#A89F95] font-semibold block">
                        Completed
                      </span>
                      <span className="text-2xl font-bold font-serif text-emerald-400 mt-1 block tabular-nums">
                        {deliveredCount} delivered
                      </span>
                      <span className="text-[11px] text-[#A89F95] mt-1 block">
                        Satisfied Karachi diners
                      </span>
                    </div>
                  </div>

                  <div className="p-5 rounded-xl bg-[#181215] border border-[#2C191D] text-xs text-[#D4CDC5] space-y-2">
                    <h4 className="font-bold text-white text-sm">Security & Audit Log</h4>
                    <p>• HTTPS connection verified with encrypted session tokens.</p>
                    <p>• Server-side price calculation enforced on all incoming checkout payloads.</p>
                    <p>• Session state is isolated to local authenticated manager token.</p>
                    <p>• WhatsApp Business endpoint verified for +92 327 3481948.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
