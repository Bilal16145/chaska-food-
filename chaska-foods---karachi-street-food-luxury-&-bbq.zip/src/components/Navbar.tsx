import React, { useState, useEffect } from 'react';
import { ShoppingBag, MessageCircle, Menu as MenuIcon, X, Globe, Clock, ShieldCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useLanguage } from '../context/LanguageContext';
import { useOrders } from '../context/OrderContext';
import { getKarachiRestaurantStatus } from '../utils/karachiTime';
import { WHATSAPP_PHONE } from '../utils/whatsapp';

interface NavbarProps {
  onOpenAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAdmin }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { totalItemCount, setIsCartOpen } = useCart();
  const { language, setLanguage, isUrdu, t } = useLanguage();
  const { setIsTrackingModalOpen } = useOrders();
  const [status, setStatus] = useState(getKarachiRestaurantStatus());

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Update Karachi time status every 30s
  useEffect(() => {
    const timer = setInterval(() => {
      setStatus(getKarachiRestaurantStatus());
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'bg-[#0D0B0C]/95 backdrop-blur-md border-b border-[#2C191D] py-3 shadow-[0_10px_30px_rgba(0,0,0,0.6)]'
          : 'bg-gradient-to-b from-[#0D0B0C]/90 to-transparent py-4 border-b border-white/5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-11">
          {/* ZONE 1: Single element wordmark brand zone */}
          <div className="flex items-center gap-3">
            <a
              href="#"
              className="flex items-center gap-2.5 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D97706]"
              aria-label="Chaska Foods Home"
            >
              <div className="w-8 h-8 rounded-full border border-[#EAB308]/60 bg-[#780A12] flex items-center justify-center shadow-[0_2px_10px_rgba(217,119,6,0.4)]">
                <span className="font-serif font-black text-xs text-[#FEF08A]">CF</span>
              </div>
              <span className="font-display font-extrabold text-xl tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-[#FFFBEB] via-[#FDE047] to-[#F59E0B]">
                Chaska Foods
              </span>
            </a>

            {/* Quiet live indicator dot */}
            <span
              className={`hidden sm:inline-flex items-center gap-1.5 px-2 py-0.5 text-[11px] font-medium rounded-full border ${
                status.isOpen
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/40'
                  : 'bg-amber-950/40 text-amber-300 border-amber-800/40'
              }`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  status.isOpen ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                }`}
              />
              <span className="whitespace-nowrap">{status.statusBadgeText}</span>
            </span>
          </div>

          {/* ZONE 2: 4-6 clean text navigation links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#E8DFD8]">
            <a
              href="#menu"
              className="hover:text-[#FBBF24] transition-colors hover:underline underline-offset-8 whitespace-nowrap"
            >
              {t('viewMenu')}
            </a>
            <a
              href="#story"
              className="hover:text-[#FBBF24] transition-colors hover:underline underline-offset-8 whitespace-nowrap"
            >
              Our Story
            </a>
            <a
              href="#reviews"
              className="hover:text-[#FBBF24] transition-colors hover:underline underline-offset-8 whitespace-nowrap"
            >
              Reviews (4.8★)
            </a>
            <a
              href="#gallery"
              className="hover:text-[#FBBF24] transition-colors hover:underline underline-offset-8 whitespace-nowrap"
            >
              Gallery
            </a>
            <a
              href="#location"
              className="hover:text-[#FBBF24] transition-colors hover:underline underline-offset-8 whitespace-nowrap"
            >
              Location & Hours
            </a>
            <button
              onClick={() => setIsTrackingModalOpen(true)}
              className="hover:text-[#FBBF24] transition-colors hover:underline underline-offset-8 whitespace-nowrap cursor-pointer text-left"
            >
              {t('trackOrder')}
            </button>
          </nav>

          {/* ZONE 3: 1-2 primary actions */}
          <div className="flex items-center gap-2.5">
            {/* Language Toggle */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'ur' : 'en')}
              className="p-1.5 sm:px-2.5 sm:py-1 rounded-md text-xs font-medium border border-[#3C2227] bg-[#1A1214] hover:bg-[#2A1B1F] text-[#F3EFEA] transition-colors flex items-center gap-1 cursor-pointer"
              title="Toggle English / Urdu"
              aria-label="Toggle Language"
            >
              <Globe className="w-3.5 h-3.5 text-[#F59E0B]" />
              <span className="whitespace-nowrap font-medium">
                {language === 'en' ? 'اردو' : 'English'}
              </span>
            </button>

            {/* Cart Trigger */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#780A12] to-[#991B1B] hover:from-[#881019] hover:to-[#B91C1C] text-[#FFFBEB] text-xs font-semibold shadow-[0_2px_12px_rgba(120,10,18,0.4)] transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap"
              aria-label={`Cart with ${totalItemCount} items`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t('cart')}</span>
              {totalItemCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-[#F59E0B] text-[#120406] font-extrabold text-[11px] tabular-nums">
                  {totalItemCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-[#F3EFEA] hover:bg-white/5 transition-colors cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#120E10] border-b border-[#2C191D] px-5 py-4 space-y-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-white/5">
            <span className="text-xs text-[#E8DFD8]/60 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#F59E0B]" />
              Karachi Time: {status.karachiTimeString}
            </span>
            <span
              className={`text-xs px-2 py-0.5 rounded-full ${
                status.isOpen
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  : 'bg-amber-950 text-amber-400 border border-amber-800'
              }`}
            >
              {status.statusBadgeText}
            </span>
          </div>

          <div className="flex flex-col gap-2.5 pt-1 text-sm font-medium text-[#E8DFD8]">
            <a
              href="#menu"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-[#FBBF24] transition-colors"
            >
              {t('viewMenu')}
            </a>
            <a
              href="#story"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-[#FBBF24] transition-colors"
            >
              Our Story
            </a>
            <a
              href="#reviews"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-[#FBBF24] transition-colors"
            >
              Google Reviews (4.8★)
            </a>
            <a
              href="#gallery"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-[#FBBF24] transition-colors"
            >
              Photo Gallery
            </a>
            <a
              href="#location"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-[#FBBF24] transition-colors"
            >
              Location & Hours
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsTrackingModalOpen(true);
              }}
              className="py-1.5 text-left hover:text-[#FBBF24] transition-colors"
            >
              {t('trackOrder')}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="py-1.5 text-left text-xs text-[#A89F95] hover:text-[#FBBF24] flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Staff / Admin Console
            </button>
          </div>

          <div className="pt-2">
            <a
              href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent('Salam Chaska Foods! I want to view today\'s specials.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#25D366] text-black font-bold text-xs shadow-md"
            >
              <MessageCircle className="w-4 h-4" />
              Direct WhatsApp (+92 327 3481948)
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
