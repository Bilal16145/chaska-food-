import React, { useState } from 'react';
import { X, Search, Clock, CheckCircle2, Flame, Bike, Phone, MessageCircle, AlertCircle } from 'lucide-react';
import { useOrders } from '../context/OrderContext';
import { Order, OrderStatus } from '../types/restaurant';
import { WHATSAPP_PHONE } from '../utils/whatsapp';

export const OrderTrackerModal: React.FC = () => {
  const {
    isTrackingModalOpen,
    setIsTrackingModalOpen,
    activeOrderToTrack,
    setActiveOrderToTrack,
    getOrderById,
  } = useOrders();

  const [searchId, setSearchId] = useState('');
  const [searchError, setSearchError] = useState<string | null>(null);

  if (!isTrackingModalOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;
    const found = getOrderById(searchId.trim());
    if (found) {
      setActiveOrderToTrack(found);
      setSearchError(null);
    } else {
      setSearchError(`No order found matching "${searchId.toUpperCase()}". Check your order code format (e.g. CF-84291).`);
    }
  };

  const getStepIndex = (status: OrderStatus): number => {
    switch (status) {
      case 'new':
        return 1;
      case 'preparing':
        return 2;
      case 'ready':
        return 3;
      case 'out_for_delivery':
        return 4;
      case 'delivered':
        return 5;
      case 'cancelled':
        return 0;
      default:
        return 1;
    }
  };

  const currentStep = activeOrderToTrack ? getStepIndex(activeOrderToTrack.status) : 1;

  const steps = [
    { title: 'Order Received', desc: 'Logged & queued', icon: CheckCircle2 },
    { title: 'Cooking & Grilling', desc: 'On wood coal sigri', icon: Flame },
    { title: 'Quality Packed', desc: 'Fresh from tandoor', icon: Clock },
    { title: 'Out with Rider', desc: 'En route in Karachi', icon: Bike },
    { title: 'Delivered', desc: 'Garam Garam Khana', icon: CheckCircle2 },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl bg-[#140F11] border border-[#2C191D] rounded-2xl shadow-2xl text-[#F3EFEA] overflow-hidden my-8">
        {/* Header */}
        <div className="p-5 border-b border-[#2C191D] bg-[#191316] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#780A12]/30 text-[#F59E0B]">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-white">
                Live Order Tracker
              </h3>
              <p className="text-xs text-[#A89F95]">
                Real-time progress for your Karachi kitchen order
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsTrackingModalOpen(false)}
            className="p-1.5 rounded-lg text-[#A89F95] hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Order Search Form */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A89F95]" />
              <input
                type="text"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                placeholder="Enter Order ID (e.g. CF-84291 or CF-71932)"
                className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl bg-[#0D0B0C] border border-[#3C2227] text-white uppercase placeholder-zinc-500 focus:outline-none focus:border-[#D97706]"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#780A12] hover:bg-[#8F0C15] text-xs font-bold text-white transition-colors"
            >
              Track
            </button>
          </form>

          {searchError && (
            <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{searchError}</span>
            </div>
          )}

          {/* Active Order Details */}
          {activeOrderToTrack ? (
            <div className="space-y-6">
              {/* Top Banner Card */}
              <div className="p-4 rounded-xl bg-[#1C1518] border border-[#332226] flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#A89F95] block">
                    Order Reference
                  </span>
                  <span className="text-xl font-bold font-serif text-[#FEF08A] tracking-wider">
                    {activeOrderToTrack.id}
                  </span>
                  <span className="text-xs text-[#D4CDC5] block mt-0.5">
                    For: <strong className="text-white">{activeOrderToTrack.customerName}</strong> ({activeOrderToTrack.orderType.toUpperCase()})
                  </span>
                </div>

                <div className="text-right">
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-xs font-bold uppercase ${
                      activeOrderToTrack.status === 'delivered'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                        : activeOrderToTrack.status === 'cancelled'
                        ? 'bg-rose-950 text-rose-300 border border-rose-700'
                        : 'bg-amber-950 text-amber-300 border border-amber-700 animate-pulse'
                    }`}
                  >
                    {activeOrderToTrack.status.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] text-[#A89F95] block mt-1">
                    Placed: {new Date(activeOrderToTrack.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>

              {/* Progress Pipeline Stepper */}
              <div className="relative pl-6 sm:pl-8 space-y-6 border-l-2 border-[#2C191D] ml-3 sm:ml-4">
                {steps.map((st, idx) => {
                  const stepNum = idx + 1;
                  const isDone = currentStep >= stepNum;
                  const isCurrent = currentStep === stepNum;
                  const Icon = st.icon;

                  return (
                    <div key={st.title} className="relative">
                      {/* Node Bullet */}
                      <div
                        className={`absolute -left-[31px] sm:-left-[39px] top-0 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          isDone
                            ? 'bg-[#25D366] text-black ring-4 ring-[#140F11]'
                            : 'bg-[#23181B] text-[#716863] ring-4 ring-[#140F11]'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                      </div>

                      <div className="pt-0.5">
                        <div className="flex items-center gap-2">
                          <h4
                            className={`text-sm font-bold ${
                              isDone ? 'text-white' : 'text-[#716863]'
                            }`}
                          >
                            {st.title}
                          </h4>
                          {isCurrent && (
                            <span className="text-[10px] font-semibold px-2 py-0.2 rounded bg-amber-500/20 text-[#F59E0B] border border-amber-500/40 animate-pulse">
                              In Progress
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#A89F95] mt-0.5">{st.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Itemized Order Summary */}
              <div className="p-4 rounded-xl bg-[#0D0B0C] border border-[#2C191D] space-y-2">
                <span className="text-xs font-bold text-white block pb-1 border-b border-[#23181B]">
                  Items in this order:
                </span>
                <div className="space-y-1 text-xs">
                  {activeOrderToTrack.items.map((it) => (
                    <div key={it.itemId} className="flex justify-between text-[#D4CDC5]">
                      <span>
                        {it.quantity}x {it.name}
                      </span>
                      <span className="tabular-nums font-semibold text-white">
                        Rs {(it.price * it.quantity).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-[#23181B] flex justify-between font-bold text-sm text-[#FEF08A]">
                  <span>Total Bill:</span>
                  <span className="font-serif tabular-nums">
                    Rs {activeOrderToTrack.total.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Need help actions */}
              <div className="flex gap-2">
                <a
                  href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(`Salam Chaska Foods, I want an update on my order ${activeOrderToTrack.id}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2.5 rounded-xl bg-[#1A2E20] hover:bg-[#233F2B] text-[#25D366] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors border border-[#25D366]/30"
                >
                  <MessageCircle className="w-4 h-4" />
                  Ask on WhatsApp
                </a>
                <a
                  href="tel:03273481948"
                  className="py-2.5 px-4 rounded-xl bg-[#21191B] hover:bg-[#2C2124] text-[#D4CDC5] hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  Call Kitchen
                </a>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-[#A89F95]">
              <p className="text-xs">
                Enter an Order ID above, or check one of our active orders like <strong className="text-white cursor-pointer" onClick={() => setActiveOrderToTrack(getOrderById('CF-84291') || null)}>CF-84291</strong>.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
