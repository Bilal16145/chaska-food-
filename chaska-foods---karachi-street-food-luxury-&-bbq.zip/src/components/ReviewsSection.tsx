import React, { useState } from 'react';
import { Star, ChevronLeft, ChevronRight, MessageSquare, ExternalLink, Quote } from 'lucide-react';
import { CUSTOMER_REVIEWS, REVIEWS_OVERVIEW } from '../data/reviewsData';
import { useLanguage } from '../context/LanguageContext';

export const ReviewsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { t } = useLanguage();

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? CUSTOMER_REVIEWS.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === CUSTOMER_REVIEWS.length - 1 ? 0 : prev + 1));
  };

  const currentReview = CUSTOMER_REVIEWS[currentIndex];

  return (
    <section id="reviews" className="py-20 bg-[#120E10] border-t border-b border-[#2C191D] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header with Rating Overview */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#F59E0B] flex items-center gap-1.5">
              <Star className="w-3.5 h-3.5 fill-[#F59E0B] text-[#F59E0B]" />
              56 Verified Google Reviews
            </span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mt-2 [text-wrap:balance]">
              Loved by Karachi’s Midnight Foodies
            </h2>
            <p className="font-urdu text-lg text-[#FDE047] font-semibold mt-1" dir="rtl">
              اہلِ کراچی کے حقیقی تاثرات اور تجربات
            </p>
          </div>

          {/* Google Score Lockup */}
          <div className="flex items-center gap-4 bg-[#181215] p-3.5 rounded-2xl border border-[#3C2227]">
            <div className="text-center px-2">
              <span className="text-3xl font-extrabold font-serif text-[#FEF08A] tabular-nums block leading-none">
                4.8
              </span>
              <div className="flex text-amber-400 mt-1 gap-0.5 justify-center">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                ))}
              </div>
            </div>

            <div className="border-l border-white/10 pl-4">
              <span className="text-xs font-semibold text-white block">Google Verified</span>
              <span className="text-[11px] text-[#A89F95] block">56 authentic ratings</span>
              <a
                href={REVIEWS_OVERVIEW.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] text-[#F59E0B] hover:text-[#FBBF24] font-medium flex items-center gap-1 mt-1 hover:underline"
              >
                <span>Rate Us on Google</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        {/* Testimonials Carousel & Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Featured Review Spotlight */}
          <div className="lg:col-span-8 bg-[#181215] border border-[#3C2227] rounded-3xl p-6 sm:p-10 relative shadow-xl">
            <Quote className="absolute top-6 right-6 w-12 h-12 text-[#780A12]/30 pointer-events-none" />

            {/* Stars */}
            <div className="flex text-amber-400 gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.floor(currentReview.rating) ? 'fill-amber-400' : 'text-zinc-600'
                  }`}
                />
              ))}
            </div>

            <p className="text-base sm:text-lg text-white font-normal leading-relaxed mb-6 italic">
              "{currentReview.comment}"
            </p>

            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#780A12] to-[#D97706] flex items-center justify-center font-bold text-sm text-white shadow-md">
                  {currentReview.author.charAt(0)}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{currentReview.author}</h4>
                  <div className="flex items-center gap-2 text-xs text-[#A89F95]">
                    <span>{currentReview.date}</span>
                    {currentReview.favoriteDish && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-[#F59E0B]">
                          Loved: {currentReview.favoriteDish}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Carousel Nav Arrows */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrev}
                  className="p-2 rounded-full bg-[#241A1E] hover:bg-[#33242A] text-white border border-[#3C2227] transition-colors"
                  aria-label="Previous review"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNext}
                  className="p-2 rounded-full bg-[#241A1E] hover:bg-[#33242A] text-white border border-[#3C2227] transition-colors"
                  aria-label="Next review"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Quick Stats & Trust Pillars */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-5 rounded-2xl bg-[#140F11] border border-[#2C191D]">
              <span className="text-xs uppercase text-[#A89F95] font-semibold block">Karachi Delivery</span>
              <h4 className="text-base font-bold text-white mt-1">Average Wait: ~35 mins</h4>
              <p className="text-xs text-[#A89F95] mt-1">
                Dishes are freshly cooked upon order receipt — never pre-microwaved or kept cold.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-[#140F11] border border-[#2C191D]">
              <span className="text-xs uppercase text-[#A89F95] font-semibold block">Family Dining</span>
              <h4 className="text-base font-bold text-white mt-1">Safe, Dedicated Seating</h4>
              <p className="text-xs text-[#A89F95] mt-1">
                Comfortable outdoor setup and family environment with prompt table attendants in Madras Commercial.
              </p>
            </div>

            <a
              href="https://maps.google.com/?q=Chaska+Foods+Karachi+Sector+17-A"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-4 rounded-2xl bg-gradient-to-r from-[#780A12] to-[#991B1B] hover:from-[#881019] hover:to-[#B91C1C] text-center text-xs font-bold text-white transition-all shadow-md"
            >
              Write a Google Review for Chaska Foods
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
