import React, { useState } from 'react';
import { Camera, X, ZoomIn } from 'lucide-react';

interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  caption: string;
}

const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Karahi & BBQ Feast',
    category: 'Table Dining',
    image: '/src/assets/images/hero_karahi_bbq_feast_1791487489742.jpg',
    caption: 'Full family feast with sizzling Chicken Karahi, Seekh Kebabs, Roghni Naan, and raita.',
  },
  {
    id: 'gal-2',
    title: 'Dum Biryani Handi',
    category: 'Degh & Rice',
    image: '/src/assets/images/chaska_biryani_platter_1791487501444.jpg',
    caption: 'Steaming Karachi Chicken Biryani infused with whole cardamom and saffron rice.',
  },
  {
    id: 'gal-3',
    title: 'Mixed Charcoal BBQ Platter',
    category: 'Charcoal Grill',
    image: '/src/assets/images/chaska_bbq_mixed_grill_1791487513103.jpg',
    caption: 'Sizzling Malai Boti, Chicken Tikka and spiced Beef Seekh Kebabs fresh off the coal sigri.',
  },
  {
    id: 'gal-4',
    title: 'Special Slow-Cooked Nalli Nihari',
    category: 'Royal Gravies',
    image: '/src/assets/images/chaska_nihari_karahi_1791487523452.jpg',
    caption: 'Traditional beef shank and bone marrow simmered for 8 hours with ginger juliennes.',
  },
  {
    id: 'gal-5',
    title: 'Evening Family Dining Ambiance',
    category: 'Restaurant Life',
    image: '/src/assets/images/chaska_restaurant_ambiance_1791487534661.jpg',
    caption: 'Warm open-air evening seating under festive lights in Scheme 33, Karachi.',
  },
];

export const GallerySection: React.FC = () => {
  const [lightboxItem, setLightboxItem] = useState<GalleryItem | null>(null);

  return (
    <section id="gallery" className="py-20 bg-[#0D0B0C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#F59E0B] flex items-center justify-center gap-1.5">
            <Camera className="w-3.5 h-3.5 text-[#F59E0B]" />
            Visual Feast • Real Kitchen Moments
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mt-2 [text-wrap:balance]">
            From Our Tandoors to Your Table
          </h2>
          <p className="text-xs text-[#A89F95] mt-2">
            Explore the colors, textures, and genuine Karachi kitchen craftsmanship behind every single dish.
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {GALLERY_ITEMS.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => setLightboxItem(item)}
              className={`group relative rounded-2xl overflow-hidden cursor-pointer border border-[#2C191D] hover:border-[#D97706]/70 transition-all duration-300 shadow-lg ${
                idx === 0 ? 'sm:col-span-2 sm:row-span-2 aspect-[16/10]' : 'aspect-[4/3]'
              }`}
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-108"
                referrerPolicy="no-referrer"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#F59E0B] tracking-wider block mb-0.5">
                    {item.category}
                  </span>
                  <h4 className="text-sm sm:text-base font-bold text-white leading-tight">
                    {item.title}
                  </h4>
                </div>
                <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  <ZoomIn className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer as required by brief section 6 */}
        <div className="text-center mt-8">
          <p className="text-[11px] text-[#716863]">
            * AI assisted food presentation photography used for online visualization; every dish is hand-cooked fresh daily by our kitchen ustaads in Karachi.
          </p>
        </div>
      </div>

      {/* Lightbox Modal */}
      {lightboxItem && (
        <div
          onClick={() => setLightboxItem(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-4xl w-full bg-[#161214] border border-[#3C2227] rounded-2xl overflow-hidden shadow-2xl"
          >
            <button
              onClick={() => setLightboxItem(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <img
              src={lightboxItem.image}
              alt={lightboxItem.title}
              className="w-full max-h-[70vh] object-cover"
              referrerPolicy="no-referrer"
            />

            <div className="p-6 bg-[#161214]">
              <span className="text-xs uppercase font-bold text-[#F59E0B]">
                {lightboxItem.category}
              </span>
              <h3 className="font-display text-xl font-bold text-white mt-1">
                {lightboxItem.title}
              </h3>
              <p className="text-xs text-[#D4CDC5] mt-1.5 leading-relaxed">
                {lightboxItem.caption}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
