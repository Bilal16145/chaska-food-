import React, { useEffect, useState } from 'react';
import { Logo } from './Logo';

export const LoadingScreen: React.FC<{ onFinish: () => void }> = ({ onFinish }) => {
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFading(true);
      setTimeout(onFinish, 600); // allow fade transition
    }, 1200);

    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div
      className={`fixed inset-0 z-50 bg-[#0D0B0C] flex flex-col items-center justify-center transition-opacity duration-600 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Ambient steam backdrop */}
      <div className="relative flex flex-col items-center">
        {/* Rising steam particles simulation */}
        <div className="absolute -top-16 inset-x-0 h-24 flex justify-center gap-6 opacity-40 pointer-events-none">
          <div className="w-8 h-20 bg-gradient-to-t from-amber-100/30 to-transparent blur-xl animate-steam" />
          <div className="w-12 h-24 bg-gradient-to-t from-white/30 to-transparent blur-xl animate-steam" style={{ animationDelay: '0.8s' }} />
        </div>

        {/* Big Animated Logo Badge */}
        <Logo size="hero" showSubtitle={false} className="animate-pulse-subtle" />

        {/* Karachi Tagline */}
        <div className="mt-8 text-center space-y-2">
          <p className="font-urdu text-xl text-[#FDE047] font-bold" dir="rtl">
            کراچی کی اصل خوشبو اور دہکتا باربی کیو
          </p>
          <div className="flex items-center justify-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#EAB308] animate-ping" />
            <span className="text-xs uppercase tracking-widest text-[#A89F95] font-semibold">
              Firing Up The Tandoor...
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
