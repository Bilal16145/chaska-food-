import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { WHATSAPP_PHONE } from '../utils/whatsapp';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const defaultMsg = encodeURIComponent(
    'Salam Chaska Foods! I would like to check today\'s special karahi and biryani.'
  );

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end pointer-events-auto">
      {/* Small dismissible tooltip */}
      {showTooltip && (
        <div className="mb-2 hidden sm:flex items-center gap-2 py-1.5 px-3 rounded-full bg-[#161214] border border-[#25D366]/40 text-xs text-[#F3EFEA] shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-300">
          <span className="w-2 h-2 rounded-full bg-[#25D366] animate-ping" />
          <span className="font-semibold text-white">Order directly on WhatsApp</span>
          <button
            onClick={() => setShowTooltip(false)}
            className="text-[#8C837C] hover:text-white ml-1 p-0.5"
            aria-label="Dismiss WhatsApp hint"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Pulsing Floating Action Button */}
      <a
        href={`https://wa.me/${WHATSAPP_PHONE}?text=${defaultMsg}`}
        target="_blank"
        rel="noopener noreferrer"
        className="w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#20ba5a] text-black shadow-[0_4px_24px_rgba(37,211,102,0.5)] flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95 group focus:outline-none focus:ring-4 focus:ring-[#25D366]/30"
        aria-label="Chat with Chaska Foods on WhatsApp"
      >
        <MessageCircle className="w-7 h-7 fill-black group-hover:scale-105 transition-transform" />
      </a>
    </div>
  );
};
