import { Review } from '../types/restaurant';

export const REVIEWS_OVERVIEW = {
  rating: 4.8,
  totalReviews: 56,
  googleMapsUrl: 'https://maps.google.com/?q=Chaska+Foods+Karachi+Sector+17-A',
  summary: 'Karachi diners consistently praise our sizzling Karahi, authentic slow-braised Nalli Nihari, spicy Dum Biryani, and melt-in-mouth Malai Boti.',
};

export const CUSTOMER_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Hamza Farooq',
    rating: 5,
    date: '2 weeks ago',
    comment: 'One of the best dining discoveries in Scheme 33! The Peshawari Chicken Karahi was sizzling and cooked to absolute perfection. Pure butter and freshly made garlic naans right out of the tandoor.',
    favoriteDish: 'Peshawari Chicken Karahi',
  },
  {
    id: 'rev-2',
    author: 'Ayesha Siddiqui',
    rating: 5,
    date: '1 month ago',
    comment: 'Ordered through WhatsApp for a family gathering in Sector 17-A. The order was received in 30 minutes, piping hot! The Chicken Malai Boti melted like butter. Highly recommended!',
    favoriteDish: 'Chicken Malai Boti',
  },
  {
    id: 'rev-3',
    author: 'Tariq Mehmood',
    rating: 5,
    date: '3 weeks ago',
    comment: 'If you want genuine Karachi taste, this is it. The Nalli Nihari had that deep caramelized color and slow-cooked bone marrow. Open till 4 AM makes it our default midnight craving spot.',
    favoriteDish: 'Special Nalli Nihari',
  },
  {
    id: 'rev-4',
    author: 'Zubair Khan',
    rating: 4.8,
    date: '1 month ago',
    comment: 'Outstanding Biryani with real fragrant sella rice, spicy potatoes, and tender chicken. Clean family atmosphere with fast table service.',
    favoriteDish: 'Karachi Special Dum Biryani',
  },
  {
    id: 'rev-5',
    author: 'Danish R.',
    rating: 5,
    date: '2 months ago',
    comment: 'Beef Behari kebabs are unbeatable here in Madras Commercial. The meat was so soft you could cut it with a fork. Mint raita and crispy paratha roll was 10/10.',
    favoriteDish: 'Beef Behari Paratha Roll',
  },
];
