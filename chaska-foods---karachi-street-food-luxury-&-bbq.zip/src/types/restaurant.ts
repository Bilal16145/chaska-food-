export type CategoryId = 
  | 'all'
  | 'bbq'
  | 'biryani'
  | 'karahi'
  | 'handi'
  | 'fast_food'
  | 'rolls'
  | 'naan'
  | 'drinks'
  | 'desserts';

export interface MenuItem {
  id: string;
  name: string;
  nameUrdu: string;
  category: CategoryId;
  description: string;
  descriptionUrdu: string;
  price: number; // in PKR
  image: string;
  isPopular?: boolean;
  isChefSpecial?: boolean;
  spiceLevel: 'mild' | 'medium' | 'hot' | 'extra-hot';
  isVegetarian?: boolean;
  serves: string;
  isAvailable: boolean;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  specialInstructions?: string;
}

export type OrderType = 'delivery' | 'pickup' | 'dine_in';

export type OrderStatus = 'new' | 'preparing' | 'ready' | 'out_for_delivery' | 'delivered' | 'cancelled';

export interface OrderItem {
  itemId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string; // e.g. CF-94812
  customerName: string;
  customerPhone: string;
  orderType: OrderType;
  address?: string;
  tableNumber?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  notes?: string;
  status: OrderStatus;
  createdAt: string; // ISO date
  whatsappSent: boolean;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  avatar?: string;
  favoriteDish?: string;
}
