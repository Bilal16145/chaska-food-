/**
 * Helper to determine live restaurant status based on Asia/Karachi (PKT, UTC+5)
 * Hours: Daily 5:00 PM to 4:00 AM
 */

export interface RestaurantStatus {
  isOpen: boolean;
  statusBadgeText: string;
  detailText: string;
  karachiTimeString: string;
  karachiHour: number;
  karachiMinute: number;
}

export function getKarachiRestaurantStatus(): RestaurantStatus {
  const now = new Date();
  
  // Format to Asia/Karachi timezone
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Karachi',
    hour: 'numeric',
    minute: 'numeric',
    hour12: false,
  });

  const parts = formatter.formatToParts(now);
  let hour = 0;
  let minute = 0;

  for (const part of parts) {
    if (part.type === 'hour') hour = parseInt(part.value, 10);
    if (part.type === 'minute') minute = parseInt(part.value, 10);
  }

  // Handle 24-hour wrap
  if (hour === 24) hour = 0;

  // Time string for display (12-hour AM/PM)
  const displayFormatter = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Karachi',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
  const karachiTimeString = displayFormatter.format(now);

  // Open daily from 17:00 (5 PM) until 04:00 (4 AM)
  // An hour is open if hour >= 17 OR hour < 4
  const isOpen = hour >= 17 || hour < 4;

  let statusBadgeText = '';
  let detailText = '';

  if (isOpen) {
    statusBadgeText = 'Open Now';
    if (hour >= 17) {
      detailText = 'Closes tonight at 4:00 AM';
    } else {
      detailText = 'Late Night Service • Closes at 4:00 AM';
    }
  } else {
    statusBadgeText = 'Closed • Opens at 5:00 PM';
    const hoursLeft = 17 - hour - (minute > 0 ? 1 : 0);
    const minutesLeft = minute > 0 ? 60 - minute : 0;
    detailText = `Reopens today at 5:00 PM (${hoursLeft > 0 ? `${hoursLeft}h ` : ''}${minutesLeft}m left)`;
  }

  return {
    isOpen,
    statusBadgeText,
    detailText,
    karachiTimeString,
    karachiHour: hour,
    karachiMinute: minute,
  };
}
