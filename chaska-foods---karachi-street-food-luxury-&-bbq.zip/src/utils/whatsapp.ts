import { Order, CartItem } from '../types/restaurant';

export const WHATSAPP_PHONE = '923273481948';
export const DISPLAY_PHONE = '0327 3481948';

/**
 * Builds the WhatsApp order text adhering precisely to the required specification:
 * 🍽️ New Order – Chaska Foods
 * Name: …
 * Phone: …
 * Type: Pickup/Delivery/Dine-in
 * Address: …
 * ───────────
 * 2x Chicken Karahi – Rs 2,400
 * 1x Garlic Naan – Rs 80
 * ───────────
 * Total: Rs 2,480
 * Notes: …
 * Order ID: CF-XXXXX
 */
export function buildWhatsAppOrderMessage(order: Order): string {
  const itemLines = order.items
    .map((item) => `${item.quantity}x ${item.name} – Rs ${item.price.toLocaleString()}`)
    .join('\n');

  const addressLine =
    order.orderType === 'delivery'
      ? `Address: ${order.address || 'Karachi, Scheme 33'}`
      : order.orderType === 'dine_in'
      ? `Dine-in Table: ${order.tableNumber || 'Walking in'}`
      : 'Pickup: Chaska Foods Branch (Scheme 33)';

  const notesLine = order.notes ? `\nNotes: ${order.notes}` : '';
  const discountLine = order.discount > 0 ? `\nDiscount Applied: -Rs ${order.discount.toLocaleString()}` : '';
  const deliveryLine = order.deliveryFee > 0 ? `\nDelivery Fee: Rs ${order.deliveryFee.toLocaleString()}` : '';

  const orderTypeLabel =
    order.orderType === 'delivery'
      ? 'Delivery'
      : order.orderType === 'pickup'
      ? 'Pickup'
      : 'Dine-in';

  return `🍽️ New Order – Chaska Foods
Name: ${order.customerName}
Phone: ${order.customerPhone}
Type: ${orderTypeLabel}
${addressLine}
───────────
${itemLines}
───────────
Subtotal: Rs ${order.subtotal.toLocaleString()}${discountLine}${deliveryLine}
Total: Rs ${order.total.toLocaleString()}${notesLine}
Order ID: ${order.id}`;
}

export function generateWhatsAppUrl(message: string): string {
  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(message)}`;
}

export function buildQuickItemWhatsAppMessage(itemName: string, price: number, qty = 1): string {
  return `Salam Chaska Foods! 🍽️
I would like to order:
${qty}x ${itemName} (Rs ${(price * qty).toLocaleString()})

Please confirm delivery to my location in Karachi.
My Phone: 
My Address: `;
}
