import React, { createContext, useContext, useState, useEffect } from 'react';
import { Order, OrderStatus, OrderType } from '../types/restaurant';

interface MenuOverride {
  price?: number;
  isAvailable?: boolean;
}

interface OrderContextType {
  orders: Order[];
  placeOrder: (data: {
    customerName: string;
    customerPhone: string;
    orderType: OrderType;
    address?: string;
    tableNumber?: string;
    items: { itemId: string; name: string; price: number; quantity: number }[];
    subtotal: number;
    deliveryFee: number;
    discount: number;
    total: number;
    notes?: string;
  }) => Order;
  getOrderById: (id: string) => Order | undefined;
  updateOrderStatus: (id: string, status: OrderStatus) => void;
  deleteOrder: (id: string) => void;
  menuOverrides: Record<string, MenuOverride>;
  updateMenuPrice: (itemId: string, newPrice: number) => void;
  toggleItemAvailability: (itemId: string) => void;
  activeOrderToTrack: Order | null;
  setActiveOrderToTrack: (order: Order | null) => void;
  isTrackingModalOpen: boolean;
  setIsTrackingModalOpen: (open: boolean) => void;
  playOrderAlertSound: () => void;
}

// Initial demo seed orders to show lively kitchen in admin and order tracking
const INITIAL_DEMO_ORDERS: Order[] = [
  {
    id: 'CF-84291',
    customerName: 'Usman Ali',
    customerPhone: '0300 2489123',
    orderType: 'delivery',
    address: 'House B-42, Sector 17-A, Scheme 33, Karachi',
    items: [
      { itemId: 'karahi-1', name: 'Peshawari Chicken Karahi', price: 1850, quantity: 1 },
      { itemId: 'naan-1', name: 'Tandoori Garlic Butter Naan', price: 120, quantity: 3 },
      { itemId: 'drink-1', name: 'Punjabi Sweet Malai Lassi', price: 260, quantity: 2 },
    ],
    subtotal: 2730,
    deliveryFee: 0,
    discount: 273,
    total: 2457,
    notes: 'Please send extra salad, lemons and mint chutney.',
    status: 'preparing',
    createdAt: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
    whatsappSent: true,
  },
  {
    id: 'CF-71932',
    customerName: 'Fatima Zahra',
    customerPhone: '0321 8847291',
    orderType: 'dine_in',
    tableNumber: 'Table 7 (Family Hall)',
    items: [
      { itemId: 'biryani-2', name: 'Special Beef Nalli Biryani', price: 890, quantity: 2 },
      { itemId: 'bbq-2', name: 'Chicken Malai Boti (8 Pcs)', price: 950, quantity: 1 },
      { itemId: 'drink-4', name: 'Chilled Pakola Soda', price: 120, quantity: 2 },
    ],
    subtotal: 2970,
    deliveryFee: 0,
    discount: 0,
    total: 2970,
    notes: 'Serving hot for dine-in family.',
    status: 'ready',
    createdAt: new Date(Date.now() - 1000 * 60 * 35).toISOString(),
    whatsappSent: true,
  },
];

const OrderContext = createContext<OrderContextType | undefined>(undefined);

// Synthesized kitchen service bell chime
function playBellChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime); // High pleasant A5 chime
    osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.1);

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 1.2);
  } catch {
    // browser auto-play policy
  }
}

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('chaska_orders');
      return saved ? JSON.parse(saved) : INITIAL_DEMO_ORDERS;
    } catch {
      return INITIAL_DEMO_ORDERS;
    }
  });

  const [menuOverrides, setMenuOverrides] = useState<Record<string, MenuOverride>>(() => {
    try {
      const saved = localStorage.getItem('chaska_menu_overrides');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [activeOrderToTrack, setActiveOrderToTrack] = useState<Order | null>(null);
  const [isTrackingModalOpen, setIsTrackingModalOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('chaska_orders', JSON.stringify(orders));
    } catch {
      // ignore
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem('chaska_menu_overrides', JSON.stringify(menuOverrides));
    } catch {
      // ignore
    }
  }, [menuOverrides]);

  const placeOrder = (data: {
    customerName: string;
    customerPhone: string;
    orderType: OrderType;
    address?: string;
    tableNumber?: string;
    items: { itemId: string; name: string; price: number; quantity: number }[];
    subtotal: number;
    deliveryFee: number;
    discount: number;
    total: number;
    notes?: string;
  }): Order => {
    // Generate order id e.g. CF-94821
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const newOrder: Order = {
      id: `CF-${randomSuffix}`,
      customerName: data.customerName,
      customerPhone: data.customerPhone,
      orderType: data.orderType,
      address: data.address,
      tableNumber: data.tableNumber,
      items: data.items,
      subtotal: data.subtotal,
      deliveryFee: data.deliveryFee,
      discount: data.discount,
      total: data.total,
      notes: data.notes,
      status: 'new',
      createdAt: new Date().toISOString(),
      whatsappSent: true,
    };

    setOrders((prev) => [newOrder, ...prev]);
    setActiveOrderToTrack(newOrder);
    playBellChime();

    return newOrder;
  };

  const getOrderById = (id: string): Order | undefined => {
    const cleanId = id.trim().toUpperCase();
    return orders.find((o) => o.id.toUpperCase() === cleanId);
  };

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, status } : o))
    );
    if (activeOrderToTrack && activeOrderToTrack.id === id) {
      setActiveOrderToTrack((prev) => (prev ? { ...prev, status } : null));
    }
  };

  const deleteOrder = (id: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== id));
  };

  const updateMenuPrice = (itemId: string, newPrice: number) => {
    setMenuOverrides((prev) => ({
      ...prev,
      [itemId]: { ...prev[itemId], price: newPrice },
    }));
  };

  const toggleItemAvailability = (itemId: string) => {
    setMenuOverrides((prev) => {
      const current = prev[itemId]?.isAvailable !== false; // default true
      return {
        ...prev,
        [itemId]: { ...prev[itemId], isAvailable: !current },
      };
    });
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        placeOrder,
        getOrderById,
        updateOrderStatus,
        deleteOrder,
        menuOverrides,
        updateMenuPrice,
        toggleItemAvailability,
        activeOrderToTrack,
        setActiveOrderToTrack,
        isTrackingModalOpen,
        setIsTrackingModalOpen,
        playOrderAlertSound: playBellChime,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => {
  const ctx = useContext(OrderContext);
  if (!ctx) throw new Error('useOrders must be used within OrderProvider');
  return ctx;
};
