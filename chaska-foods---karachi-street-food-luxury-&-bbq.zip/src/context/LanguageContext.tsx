import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'ur';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  isUrdu: boolean;
  t: (key: string) => string;
}

const translations: Record<string, { en: string; ur: string }> = {
  restaurantName: { en: 'Chaska Foods', ur: 'چسکا فوڈز' },
  tagline: { en: 'Karachi Street-Food Luxury', ur: 'کراچی اسٹریٹ فوڈ کی شاہی لذت' },
  orderWhatsApp: { en: 'Order on WhatsApp', ur: 'واٹس ایپ پر آرڈر کریں' },
  viewMenu: { en: 'Explore Menu', ur: 'مینو دیکھیں' },
  trackOrder: { en: 'Track Order', ur: 'آرڈر ٹریک کریں' },
  cart: { en: 'Your Cart', ur: 'آپ کا آرڈر' },
  openNow: { en: 'Open Now', ur: 'کھلا ہے' },
  closed: { en: 'Closed • Opens 5 PM', ur: 'بند ہے • شام 5 بجے کھلے گا' },
  addToCart: { en: 'Add to Cart', ur: 'آرڈر میں شامل کریں' },
  added: { en: 'Added!', ur: 'شامل ہو گیا!' },
  quickOrder: { en: 'Direct WhatsApp', ur: 'براہ راست واٹس ایپ' },
  delivery: { en: 'Delivery', ur: 'ڈلیوری' },
  pickup: { en: 'Pickup', ur: 'پک اپ' },
  dineIn: { en: 'Dine-in', ur: 'ڈائن ان' },
  subtotal: { en: 'Subtotal', ur: 'میزان' },
  deliveryFee: { en: 'Delivery Fee', ur: 'ڈلیوری فیس' },
  discount: { en: 'Discount', ur: 'رعایت' },
  total: { en: 'Total Amount', ur: 'کل رقم' },
  checkout: { en: 'Proceed to WhatsApp Checkout', ur: 'واٹس ایپ پر آرڈر مکمل کریں' },
  aboutTitle: { en: 'The Royal Charcoal Heritage of Karachi', ur: 'کراچی کا مستند ذائقہ اور کوئلے کی روایتی تیاری' },
  reviewsTitle: { en: 'Trusted by Karachi Foodies', ur: 'اہلِ کراچی کی پسند اور جائزے' },
  locationTitle: { en: 'Visit Us in Karachi', ur: 'چسکا فوڈز پر تشریف لائیں' },
  faqTitle: { en: 'Frequently Asked Questions', ur: 'اکثر پوچھے جانے والے سوالات' },
  adminPortal: { en: 'Staff Console', ur: 'اسٹاف پورٹل' },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const saved = localStorage.getItem('chaska_lang') as Language;
    if (saved === 'en' || saved === 'ur') {
      setLanguage(saved);
    }
  }, []);

  const changeLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('chaska_lang', lang);
    if (lang === 'ur') {
      document.documentElement.setAttribute('dir', 'rtl');
    } else {
      document.documentElement.setAttribute('dir', 'ltr');
    }
  };

  const t = (key: string): string => {
    const entry = translations[key];
    if (!entry) return key;
    return entry[language] || entry.en;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage: changeLanguage,
        isUrdu: language === 'ur',
        t,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
};
