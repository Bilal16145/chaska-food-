import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { CartItem, MenuItem } from '../types/restaurant';

interface CartContextType {
  items: CartItem[];
  addItem: (item: MenuItem, qty?: number, instructions?: string) => void;
  removeItem: (itemId: string) => void;
  updateQuantity: (itemId: string, delta: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  couponCode: string;
  discountAmount: number;
  couponError: string | null;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  subtotal: number;
  deliveryFee: number;
  total: number;
  totalItemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('chaska_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [fixedDiscount, setFixedDiscount] = useState(0);
  const [couponError, setCouponError] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('chaska_cart', JSON.stringify(items));
    } catch {
      // storage quota or private mode
    }
  }, [items]);

  const addItem = (item: MenuItem, qty = 1, instructions = '') => {
    setItems((prev) => {
      const existing = prev.find((i) => i.menuItem.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.menuItem.id === item.id
            ? { ...i, quantity: i.quantity + qty, specialInstructions: instructions || i.specialInstructions }
            : i
        );
      }
      return [...prev, { menuItem: item, quantity: qty, specialInstructions: instructions }];
    });
  };

  const removeItem = (itemId: string) => {
    setItems((prev) => prev.filter((i) => i.menuItem.id !== itemId));
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setItems((prev) => {
      return prev
        .map((i) => {
          if (i.menuItem.id === itemId) {
            const nextQty = i.quantity + delta;
            return nextQty > 0 ? { ...i, quantity: nextQty } : null;
          }
          return i;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const clearCart = () => {
    setItems([]);
    setCouponCode('');
    setDiscountPercent(0);
    setFixedDiscount(0);
  };

  const totalItemCount = useMemo(() => {
    return items.reduce((sum, item) => sum + item.quantity, 0);
  }, [items]);

  const subtotal = useMemo(() => {
    return items.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0);
  }, [items]);

  const deliveryFee = useMemo(() => {
    if (subtotal === 0) return 0;
    // Free delivery for orders above Rs 2,500
    if (subtotal >= 2500) return 0;
    return 150; // standard Karachi Scheme 33 delivery
  }, [subtotal]);

  const discountAmount = useMemo(() => {
    if (discountPercent > 0) {
      return Math.round((subtotal * discountPercent) / 100);
    }
    return Math.min(fixedDiscount, subtotal);
  }, [subtotal, discountPercent, fixedDiscount]);

  const total = useMemo(() => {
    if (subtotal === 0) return 0;
    return Math.max(0, subtotal - discountAmount + deliveryFee);
  }, [subtotal, discountAmount, deliveryFee]);

  const applyCoupon = (code: string): boolean => {
    const clean = code.trim().toUpperCase();
    if (!clean) return false;

    if (clean === 'CHASKA10') {
      setCouponCode('CHASKA10');
      setDiscountPercent(10);
      setFixedDiscount(0);
      setCouponError(null);
      return true;
    }
    if (clean === 'FIRSTORDER') {
      setCouponCode('FIRSTORDER');
      setDiscountPercent(0);
      setFixedDiscount(150);
      setCouponError(null);
      return true;
    }
    if (clean === 'KARACHI50') {
      setCouponCode('KARACHI50');
      setDiscountPercent(0);
      setFixedDiscount(50);
      setCouponError(null);
      return true;
    }

    setCouponError('Invalid coupon. Try CHASKA10 or FIRSTORDER');
    return false;
  };

  const removeCoupon = () => {
    setCouponCode('');
    setDiscountPercent(0);
    setFixedDiscount(0);
    setCouponError(null);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        couponCode,
        discountAmount,
        couponError,
        applyCoupon,
        removeCoupon,
        subtotal,
        deliveryFee,
        total,
        totalItemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
};
