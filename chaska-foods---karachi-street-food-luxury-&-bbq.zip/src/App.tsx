import React, { useState } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { CartProvider } from './context/CartContext';
import { OrderProvider } from './context/OrderContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { MenuSection } from './components/MenuSection';
import { ReviewsSection } from './components/ReviewsSection';
import { GallerySection } from './components/GallerySection';
import { LocationHoursSection } from './components/LocationHoursSection';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { AdminDashboard } from './components/AdminDashboard';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { LoadingScreen } from './components/LoadingScreen';

function MainLayout() {
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  return (
    <div className="min-h-screen bg-[#0D0B0C] text-[#F3EFEA] flex flex-col selection:bg-[#D97706] selection:text-white relative">
      {/* Initial Loading Screen */}
      {isLoading && <LoadingScreen onFinish={() => setIsLoading(false)} />}

      {/* Top Navbar */}
      <Navbar onOpenAdmin={() => setIsAdminOpen(true)} />

      {/* Main Page Content */}
      <main className="flex-1">
        <Hero />
        <AboutSection />
        <MenuSection />
        <ReviewsSection />
        <GallerySection />
        <LocationHoursSection />
        <FAQSection />
      </main>

      {/* Footer */}
      <Footer onOpenAdmin={() => setIsAdminOpen(true)} />

      {/* Slide-over Cart Drawer */}
      <CartDrawer />

      {/* WhatsApp Checkout Modal */}
      <CheckoutModal />

      {/* Live Order Tracker Modal */}
      <OrderTrackerModal />

      {/* Staff Admin Console */}
      <AdminDashboard isOpen={isAdminOpen} onClose={() => setIsAdminOpen(false)} />

      {/* Persistent Floating WhatsApp Action Button */}
      <FloatingWhatsApp />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <OrderProvider>
        <CartProvider>
          <MainLayout />
        </CartProvider>
      </OrderProvider>
    </LanguageProvider>
  );
}
